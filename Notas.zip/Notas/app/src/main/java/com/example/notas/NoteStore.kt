package com.example.notas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Note(
    val id: Long,
    var title: String = "",
    var body: String = "",
    var bgColor: Int = 0xFFFFF59D.toInt(),
    var textColor: Int = 0xFF212121.toInt(),
    var textSize: Int = 18,
    var opacity: Int = 100,
    var scrim: Int = 30,
    var updated: Long = System.currentTimeMillis()
)

object NoteStore {
    private const val FILE = "notes.json"
    private const val PREFS = "notes_prefs"

    private fun load(ctx: Context): MutableList<Note> {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            val list = mutableListOf<Note>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Note(
                        id = o.getLong("id"),
                        title = o.optString("title", ""),
                        body = o.optString("body", ""),
                        bgColor = o.optInt("bg", 0xFFFFF59D.toInt()),
                        textColor = o.optInt("fg", 0xFF212121.toInt()),
                        textSize = o.optInt("size", 18),
                        opacity = o.optInt("opacity", 100),
                        scrim = o.optInt("scrim", 30),
                        updated = o.optLong("updated", 0L)
                    )
                )
            }
            list
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun save(ctx: Context, list: List<Note>) {
        val arr = JSONArray()
        for (n in list) {
            val o = JSONObject()
            o.put("id", n.id)
            o.put("title", n.title)
            o.put("body", n.body)
            o.put("bg", n.bgColor)
            o.put("fg", n.textColor)
            o.put("size", n.textSize)
            o.put("opacity", n.opacity)
            o.put("scrim", n.scrim)
            o.put("updated", n.updated)
            arr.put(o)
        }
        File(ctx.filesDir, FILE).writeText(arr.toString())
    }

    fun all(ctx: Context): List<Note> = load(ctx).sortedByDescending { it.updated }

    fun get(ctx: Context, id: Long): Note? = load(ctx).firstOrNull { it.id == id }

    fun upsert(ctx: Context, note: Note) {
        val list = load(ctx)
        val i = list.indexOfFirst { it.id == note.id }
        if (i >= 0) list[i] = note else list.add(note)
        save(ctx, list)
    }

    fun delete(ctx: Context, id: Long) {
        val list = load(ctx)
        list.removeAll { it.id == id }
        save(ctx, list)
        imageFile(ctx, id).delete()
    }

    fun imageFile(ctx: Context, id: Long): File = File(ctx.filesDir, "img_$id.jpg")

    // Qué nota muestra cada widget
    fun widgetNote(ctx: Context, widgetId: Int): Long =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("w_$widgetId", -1L)

    fun setWidgetNote(ctx: Context, widgetId: Int, noteId: Long) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong("w_$widgetId", noteId).apply()
    }

    fun clearWidget(ctx: Context, widgetId: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("w_$widgetId").apply()
    }
}
