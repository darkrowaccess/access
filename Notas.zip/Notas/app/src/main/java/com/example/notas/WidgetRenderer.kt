package com.example.notas

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.max
import kotlin.math.min

object WidgetRenderer {

    /** Dibuja el fondo de la nota (color, imagen, esquinas redondeadas y opacidad). */
    fun render(ctx: Context, mgr: AppWidgetManager, id: Int, note: Note): Bitmap {
        val o = mgr.getAppWidgetOptions(id)
        val minW = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        val maxW = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        val minH = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
        val maxH = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        val portrait = ctx.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        var wDp = if (portrait) minW else maxW
        var hDp = if (portrait) maxH else minH
        if (wDp <= 0) wDp = 250
        if (hDp <= 0) hDp = 110

        val density = ctx.resources.displayMetrics.density
        var w = wDp * density
        var h = hDp * density
        val k = min(1f, 900f / max(w, h))
        w *= k
        h *= k
        val bw = max(w.toInt(), 100)
        val bh = max(h.toInt(), 100)
        val radius = 22f * density * k

        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rect = RectF(0f, 0f, bw.toFloat(), bh.toFloat())

        c.drawColor(note.bgColor or 0xFF000000.toInt())

        val file = NoteStore.imageFile(ctx, note.id)
        if (file.exists()) {
            val img = BitmapFactory.decodeFile(file.path)
            if (img != null) {
                val scale = max(bw.toFloat() / img.width, bh.toFloat() / img.height)
                val srcW = (bw / scale).toInt()
                val srcH = (bh / scale).toInt()
                val left = (img.width - srcW) / 2
                val top = (img.height - srcH) / 2
                val src = Rect(left, top, left + srcW, top + srcH)
                c.drawBitmap(img, src, rect, Paint(Paint.FILTER_BITMAP_FLAG))
                img.recycle()
                c.drawColor(Color.argb(note.scrim * 255 / 100, 0, 0, 0))
            }
        }

        val mask = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val mc = Canvas(mask)
        val mp = Paint(Paint.ANTI_ALIAS_FLAG)
        mp.color = Color.argb(note.opacity * 255 / 100, 255, 255, 255)
        mc.drawRoundRect(rect, radius, radius, mp)
        val dstIn = Paint(Paint.FILTER_BITMAP_FLAG)
        dstIn.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        c.drawBitmap(mask, 0f, 0f, dstIn)
        mask.recycle()
        return bmp
    }
}
