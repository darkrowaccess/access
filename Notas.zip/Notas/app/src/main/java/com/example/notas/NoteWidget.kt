package com.example.notas

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews

class NoteWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    override fun onAppWidgetOptionsChanged(
        ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(ctx, mgr, id, newOptions)
        update(ctx, mgr, id)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach { NoteStore.clearWidget(ctx, it) }
    }

    companion object {
        fun refreshAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, NoteWidget::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val noteId = NoteStore.widgetNote(ctx, id)
            val saved = if (noteId >= 0) NoteStore.get(ctx, noteId) else null
            val missing = saved == null
            val note = saved ?: Note(
                id = -1L,
                title = "Nota no disponible",
                body = "Toca el widget para abrir la app de Notas."
            )

            val views = RemoteViews(ctx.packageName, R.layout.widget_note)
            views.setImageViewBitmap(R.id.bg_image, WidgetRenderer.render(ctx, mgr, id, note))

            if (note.title.isBlank()) {
                views.setViewVisibility(R.id.note_title, View.GONE)
            } else {
                views.setViewVisibility(R.id.note_title, View.VISIBLE)
                views.setTextViewText(R.id.note_title, note.title)
            }
            views.setTextViewText(R.id.note_body, note.body)
            views.setTextColor(R.id.note_title, note.textColor)
            views.setTextColor(R.id.note_body, note.textColor)
            views.setTextViewTextSize(R.id.note_title, TypedValue.COMPLEX_UNIT_SP, (note.textSize + 4).toFloat())
            views.setTextViewTextSize(R.id.note_body, TypedValue.COMPLEX_UNIT_SP, note.textSize.toFloat())

            val intent = if (missing) {
                Intent(ctx, MainActivity::class.java)
            } else {
                Intent(ctx, EditActivity::class.java).putExtra("note_id", note.id)
            }
            val pi = PendingIntent.getActivity(
                ctx, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            mgr.updateAppWidget(id, views)
        }
    }
}
