package com.example.notas

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputFilter
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

/** Pequeñas piezas de interfaz que se reutilizan en varias pantallas. */
class Ui(private val ctx: Context) {

    companion object {
        val PALETTE = intArrayOf(
            0xFFFFF59D.toInt(), 0xFFFFCCBC.toInt(), 0xFFC8E6C9.toInt(), 0xFFBBDEFB.toInt(),
            0xFFE1BEE7.toInt(), 0xFFFFFFFF.toInt(), 0xFF212121.toInt(), 0xFF1F2A44.toInt(),
            0xFF1B5E20.toInt(), 0xFF6D1B34.toInt(), 0xFFF5C451.toInt()
        )
    }

    fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

    fun header(text: String): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 18f
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, dp(8), 0, dp(6))
        return t
    }

    fun label(text: String): TextView {
        val t = TextView(ctx)
        t.text = text
        t.setPadding(0, dp(12), 0, 0)
        return t
    }

    fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(ctx)
        b.text = text
        b.setOnClickListener { onClick() }
        return b
    }

    fun spinnerRow(options: List<String>, selected: Int, onChange: (Int) -> Unit): Spinner {
        val s = Spinner(ctx)
        s.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, options)
        s.setSelection(selected)
        var first = true
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) {
                    first = false
                    return
                }
                onChange(pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return s
    }

    fun colorPicker(current: Int, onPick: (Int) -> Unit): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL

        val edit = EditText(ctx)
        edit.hint = "#RRGGBB"
        edit.setText(hex(current))
        edit.setSingleLine()
        edit.filters = arrayOf(InputFilter.LengthFilter(7))

        val row = LinearLayout(ctx)
        for (c in PALETTE) {
            val dot = View(ctx)
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            dot.layoutParams = lp
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.OVAL
            shape.setColor(c)
            shape.setStroke(dp(2), 0xFF888888.toInt())
            dot.background = shape
            dot.setOnClickListener {
                edit.setText(hex(c))
                onPick(c)
            }
            row.addView(dot)
        }
        val scroll = HorizontalScrollView(ctx)
        scroll.addView(row)
        box.addView(scroll)

        val hexRow = LinearLayout(ctx)
        hexRow.orientation = LinearLayout.HORIZONTAL
        hexRow.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val apply = Button(ctx)
        apply.text = "Aplicar"
        apply.setOnClickListener {
            try {
                onPick(Color.parseColor(edit.text.toString().trim()))
            } catch (e: IllegalArgumentException) {
                Toast.makeText(ctx, "Color no válido. Usa el formato #RRGGBB", Toast.LENGTH_SHORT).show()
            }
        }
        hexRow.addView(apply)
        box.addView(hexRow)
        return box
    }

    fun seekRow(title: String, current: Int, maxValue: Int, onDone: (Int) -> Unit): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val label = TextView(ctx)
        label.text = "$title: $current%"
        label.setPadding(0, dp(12), 0, 0)
        val bar = SeekBar(ctx)
        bar.max = maxValue
        bar.progress = current
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "$title: $p%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                onDone(bar.progress)
            }
        })
        box.addView(label)
        box.addView(bar)
        return box
    }
}
