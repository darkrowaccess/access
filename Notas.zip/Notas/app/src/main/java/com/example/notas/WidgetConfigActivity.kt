package com.example.notas

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Se abre al añadir el widget para elegir qué nota mostrar. */
class WidgetConfigActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)

        val widgetId = intent.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val ui = Ui(this)
        val notes = NoteStore.all(this)
        val labels = ArrayList<String>()
        labels.add("➕  Crear una nota nueva")
        for (n in notes) {
            labels.add(if (n.title.isNotBlank()) n.title else n.body.take(30).ifBlank { "(Sin título)" })
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ui.dp(16), ui.dp(16), ui.dp(16), ui.dp(16))

        val title = TextView(this)
        title.text = "Elige la nota para este widget"
        title.textSize = 20f
        title.setPadding(0, 0, 0, ui.dp(12))
        root.addView(title)

        val list = ListView(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        list.setOnItemClickListener { _, _, position, _ ->
            val noteId: Long
            if (position == 0) {
                val n = Note(
                    id = System.currentTimeMillis(),
                    title = "Nueva nota",
                    body = "Toca el widget para escribir aquí."
                )
                NoteStore.upsert(this, n)
                noteId = n.id
            } else {
                noteId = notes[position - 1].id
            }
            NoteStore.setWidgetNote(this, widgetId, noteId)
            NoteWidget.update(this, AppWidgetManager.getInstance(this), widgetId)
            val result = Intent()
            result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            setResult(RESULT_OK, result)
            finish()
        }
        root.addView(list)
        setContentView(root)
    }
}
