package com.example.notas

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var ui: Ui
    private lateinit var adapter: NoteAdapter
    private val thumbs = HashMap<String, Bitmap?>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        adapter = NoteAdapter()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(ui.dp(16), ui.dp(12), ui.dp(12), ui.dp(4))
        val title = TextView(this)
        title.text = "Mis notas"
        title.textSize = 24f
        title.setTypeface(null, Typeface.BOLD)
        top.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val add = Button(this)
        add.text = "+ Nueva nota"
        add.setOnClickListener { startActivity(Intent(this, EditActivity::class.java)) }
        top.addView(add)
        root.addView(top)

        val hint = TextView(this)
        hint.text = "Para el widget: mantén presionado un espacio vacío de tu pantalla de inicio → Widgets → Notas."
        hint.textSize = 13f
        hint.setPadding(ui.dp(16), 0, ui.dp(16), ui.dp(8))
        root.addView(hint)

        val list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            val i = Intent(this, EditActivity::class.java)
            i.putExtra("note_id", adapter.getItemId(position))
            startActivity(i)
        }
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val empty = TextView(this)
        empty.text = "Todavía no tienes notas.\nToca «+ Nueva nota» para crear la primera."
        empty.gravity = Gravity.CENTER
        empty.setPadding(ui.dp(24), ui.dp(48), ui.dp(24), ui.dp(24))
        root.addView(
            empty,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
        )
        list.emptyView = empty

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        adapter.items = NoteStore.all(this)
        adapter.notifyDataSetChanged()
    }

    private fun thumb(n: Note): Bitmap? {
        val key = "${n.id}_${n.updated}"
        if (thumbs.containsKey(key)) return thumbs[key]
        val f = NoteStore.imageFile(this, n.id)
        var bmp: Bitmap? = null
        if (f.exists()) {
            val o = BitmapFactory.Options()
            o.inSampleSize = 8
            bmp = BitmapFactory.decodeFile(f.path, o)
        }
        thumbs[key] = bmp
        return bmp
    }

    private inner class NoteAdapter : BaseAdapter() {
        var items: List<Note> = emptyList()

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val n = items[position]
            val outer = FrameLayout(this@MainActivity)
            outer.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6))

            val card = LinearLayout(this@MainActivity)
            card.orientation = LinearLayout.HORIZONTAL
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12))
            val bg = GradientDrawable()
            bg.cornerRadius = ui.dp(14).toFloat()
            bg.setColor(n.bgColor)
            card.background = bg

            val t = thumb(n)
            if (t != null) {
                val iv = ImageView(this@MainActivity)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.setImageBitmap(t)
                val lp = LinearLayout.LayoutParams(ui.dp(56), ui.dp(56))
                lp.rightMargin = ui.dp(12)
                card.addView(iv, lp)
            }

            val col = LinearLayout(this@MainActivity)
            col.orientation = LinearLayout.VERTICAL
            val title = TextView(this@MainActivity)
            title.text = if (n.title.isNotBlank()) n.title else "(Sin título)"
            title.textSize = 17f
            title.setTypeface(null, Typeface.BOLD)
            title.setTextColor(n.textColor)
            title.maxLines = 1
            col.addView(title)
            if (n.body.isNotBlank()) {
                val snip = TextView(this@MainActivity)
                snip.text = n.body
                snip.textSize = 14f
                snip.setTextColor(n.textColor)
                snip.maxLines = 2
                col.addView(snip)
            }
            card.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            outer.addView(card)
            return outer
        }
    }
}
