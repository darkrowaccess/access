package com.example.notas

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class EditActivity : Activity() {

    private lateinit var note: Note
    private var isNew = false
    private var deleted = false

    private lateinit var ui: Ui
    private lateinit var frame: FrameLayout
    private lateinit var bgImage: ImageView
    private lateinit var scrimView: View
    private lateinit var titleEdit: EditText
    private lateinit var bodyEdit: EditText

    private val reqImage = 7
    private val sizeLabels = listOf("Pequeña", "Mediana", "Grande", "Muy grande", "Enorme")
    private val sizes = listOf(14, 18, 22, 26, 32)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)

        val id = intent.getLongExtra("note_id", -1L)
        val existing = if (id >= 0) NoteStore.get(this, id) else null
        isNew = existing == null
        note = existing ?: Note(id = if (id >= 0) id else System.currentTimeMillis())

        val match = FrameLayout.LayoutParams.MATCH_PARENT
        frame = FrameLayout(this)
        bgImage = ImageView(this)
        bgImage.scaleType = ImageView.ScaleType.CENTER_CROP
        frame.addView(bgImage, FrameLayout.LayoutParams(match, match))
        scrimView = View(this)
        frame.addView(scrimView, FrameLayout.LayoutParams(match, match))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(16), ui.dp(24), ui.dp(16), ui.dp(24))

        titleEdit = EditText(this)
        titleEdit.hint = "Título"
        titleEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        titleEdit.setTypeface(null, Typeface.BOLD)
        titleEdit.setText(note.title)
        titleEdit.background = null
        content.addView(titleEdit)

        bodyEdit = EditText(this)
        bodyEdit.hint = "Escribe tu nota…"
        bodyEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        bodyEdit.minLines = 8
        bodyEdit.gravity = Gravity.TOP or Gravity.START
        bodyEdit.setText(note.body)
        bodyEdit.background = null
        content.addView(bodyEdit)

        // Panel de personalización
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(14))
        val cardBg = GradientDrawable()
        cardBg.cornerRadius = ui.dp(16).toFloat()
        cardBg.setColor(0xF2FFFFFF.toInt())
        card.background = cardBg

        card.addView(ui.header("Personalizar"))
        card.addView(ui.label("Tamaño de letra"))
        card.addView(
            ui.spinnerRow(sizeLabels, sizes.indexOf(note.textSize).coerceAtLeast(1)) { pos ->
                note.textSize = sizes[pos]
                applyLook()
            }
        )
        card.addView(ui.label("Color de la letra"))
        card.addView(ui.colorPicker(note.textColor) { c ->
            note.textColor = c or 0xFF000000.toInt()
            applyLook()
        })
        card.addView(ui.label("Color de fondo"))
        card.addView(ui.colorPicker(note.bgColor) { c ->
            note.bgColor = c or 0xFF000000.toInt()
            applyLook()
        })
        card.addView(ui.button("Elegir imagen de fondo de la galería") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Elegir imagen"), reqImage)
        })
        card.addView(ui.button("Quitar imagen de fondo") {
            NoteStore.imageFile(this, note.id).delete()
            applyLook()
            saveNow()
        })
        card.addView(ui.seekRow("Oscurecer la imagen", note.scrim, 80) { v ->
            note.scrim = v
            applyLook()
        })
        card.addView(ui.seekRow("Opacidad del fondo en el widget", note.opacity, 100) { v ->
            note.opacity = v
        })
        card.addView(ui.button("Eliminar nota") {
            AlertDialog.Builder(this)
                .setTitle("¿Eliminar esta nota?")
                .setPositiveButton("Eliminar") { _, _ ->
                    deleted = true
                    NoteStore.delete(this, note.id)
                    NoteWidget.refreshAll(this)
                    finish()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        })

        val cardLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        cardLp.topMargin = ui.dp(28)
        content.addView(card, cardLp)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(content)
        frame.addView(scroll, FrameLayout.LayoutParams(match, match))

        setContentView(frame)
        applyLook()
    }

    /** Aplica color, imagen, tamaño y color de letra a la pantalla de edición. */
    private fun applyLook() {
        frame.setBackgroundColor(note.bgColor)
        val hint = (note.textColor and 0x00FFFFFF) or (0x80 shl 24)
        titleEdit.setTextColor(note.textColor)
        bodyEdit.setTextColor(note.textColor)
        titleEdit.setHintTextColor(hint)
        bodyEdit.setHintTextColor(hint)
        titleEdit.textSize = (note.textSize + 4).toFloat()
        bodyEdit.textSize = note.textSize.toFloat()

        val f = NoteStore.imageFile(this, note.id)
        if (f.exists()) {
            bgImage.setImageBitmap(BitmapFactory.decodeFile(f.path))
            scrimView.setBackgroundColor(Color.argb(note.scrim * 255 / 100, 0, 0, 0))
        } else {
            bgImage.setImageDrawable(null)
            scrimView.setBackgroundColor(Color.TRANSPARENT)
        }
    }

    private fun saveNow() {
        if (deleted) return
        note.title = titleEdit.text.toString().trim()
        note.body = bodyEdit.text.toString()
        val hasImage = NoteStore.imageFile(this, note.id).exists()
        if (isNew && note.title.isEmpty() && note.body.isBlank() && !hasImage) return
        note.updated = System.currentTimeMillis()
        NoteStore.upsert(this, note)
        isNew = false
        NoteWidget.refreshAll(this)
    }

    override fun onPause() {
        super.onPause()
        saveNow()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqImage || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val ok = ImageUtil.saveFromUri(this, uri, NoteStore.imageFile(this, note.id))
            runOnUiThread {
                if (ok) {
                    applyLook()
                    saveNow()
                }
                Toast.makeText(
                    this,
                    if (ok) "Imagen aplicada a la nota" else "No se pudo usar esa imagen",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }.start()
    }
}
