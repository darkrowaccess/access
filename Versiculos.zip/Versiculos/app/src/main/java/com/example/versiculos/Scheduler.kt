package com.example.versiculos

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class VerseWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        VerseRepository.next(applicationContext)
        VerseWidget.refreshAll(applicationContext)
        return Result.success()
    }
}

object Scheduler {
    private const val NAME = "verse_update"

    fun schedule(ctx: Context) {
        // WorkManager exige un mínimo de 15 minutos.
        val minutes = VerseRepository.intervalMinutes(ctx).coerceAtLeast(15L)
        val request = PeriodicWorkRequestBuilder<VerseWorker>(minutes, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    fun cancel(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
    }
}
