package com.example.versiculos

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.widget.RemoteViews

class VerseWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    override fun onAppWidgetOptionsChanged(
        ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(ctx, mgr, id, newOptions)
        update(ctx, mgr, id)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_NEXT) {
            VerseRepository.next(ctx)
            refreshAll(ctx)
        }
    }

    override fun onEnabled(ctx: Context) {
        Scheduler.schedule(ctx)
    }

    override fun onDisabled(ctx: Context) {
        Scheduler.cancel(ctx)
    }

    companion object {
        const val ACTION_NEXT = "com.example.versiculos.NEXT"

        fun refreshAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, VerseWidget::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        private fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val verse = VerseRepository.current(ctx)
            val views = RemoteViews(ctx.packageName, R.layout.widget_verse)

            views.setImageViewBitmap(R.id.bg_image, WidgetRenderer.render(ctx, mgr, id))

            views.setTextViewText(R.id.verse_text, verse.text)
            views.setTextViewText(R.id.verse_ref, verse.ref)

            val size = VerseRepository.textSizeSp(ctx).toFloat()
            views.setTextViewTextSize(R.id.verse_text, TypedValue.COMPLEX_UNIT_SP, size)
            views.setTextViewTextSize(R.id.verse_ref, TypedValue.COMPLEX_UNIT_SP, size * 0.75f)

            val tc = VerseRepository.textColor(ctx)
            views.setTextColor(R.id.verse_text, tc)
            views.setTextColor(R.id.verse_ref, (tc and 0x00FFFFFF) or (0xCC shl 24))

            val intent = Intent(ctx, VerseWidget::class.java).setAction(ACTION_NEXT)
            val pi = PendingIntent.getBroadcast(
                ctx, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pi)
            mgr.updateAppWidget(id, views)
        }
    }
}
