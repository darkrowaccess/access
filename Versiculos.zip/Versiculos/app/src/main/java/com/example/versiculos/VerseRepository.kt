package com.example.versiculos

import android.content.Context
import kotlin.random.Random

object VerseRepository {
    data class Verse(val ref: String, val text: String)

    private const val PREFS = "verse_prefs"
    private var cache: List<Verse>? = null

    private fun all(ctx: Context): List<Verse> = cache ?: ctx.assets.open("versiculos.txt")
        .bufferedReader()
        .useLines { lines ->
            lines.map { it.trim() }
                .filter { it.isNotEmpty() && '|' in it }
                .map {
                    val parts = it.split("|", limit = 2)
                    Verse(parts[0].trim(), parts[1].trim())
                }.toList()
        }.also { cache = it }

    /** Elige un versículo al azar (distinto del actual) y lo guarda. */
    fun next(ctx: Context): Verse {
        val list = all(ctx)
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val last = prefs.getInt("index", -1)
        var i = Random.nextInt(list.size)
        if (list.size > 1) while (i == last) i = Random.nextInt(list.size)
        prefs.edit().putInt("index", i).apply()
        return list[i]
    }

    fun current(ctx: Context): Verse {
        val list = all(ctx)
        val i = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("index", -1)
        return if (i in list.indices) list[i] else next(ctx)
    }

    fun intervalMinutes(ctx: Context): Long =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("interval", 60L)

    fun setIntervalMinutes(ctx: Context, minutes: Long) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong("interval", minutes).apply()
    }

    fun textSizeSp(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("text_size", 24)

    fun setTextSizeSp(ctx: Context, sp: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("text_size", sp).apply()
    }

    fun getInt(ctx: Context, key: String, def: Int): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(key, def)

    fun putInt(ctx: Context, key: String, value: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(key, value).apply()
    }

    fun bgColor(ctx: Context): Int = getInt(ctx, "bg_color", 0xFF1F2A44.toInt())
    fun textColor(ctx: Context): Int = getInt(ctx, "text_color", 0xFFFFFFFF.toInt())
    fun bgOpacity(ctx: Context): Int = getInt(ctx, "bg_opacity", 90)
    fun scrim(ctx: Context): Int = getInt(ctx, "scrim", 35)

    fun bgImageFile(ctx: Context): java.io.File = java.io.File(ctx.filesDir, "widget_bg.jpg")
}
