package com.example.versiculos

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {

    private val labels = listOf(
        "Cada 15 minutos", "Cada 30 minutos", "Cada hora",
        "Cada 3 horas", "Cada 6 horas", "Cada 12 horas", "Cada día"
    )
    private val minutes = listOf(15L, 30L, 60L, 180L, 360L, 720L, 1440L)
    private val sizeLabels = listOf("Pequeña", "Mediana", "Grande", "Muy grande", "Enorme")
    private val sizes = listOf(16, 20, 24, 28, 34)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Versículos"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Para añadir el widget: mantén presionado un espacio vacío de tu pantalla " +
                "de inicio → Widgets → Versículos. Toca el widget para cambiar de versículo al instante."
            setPadding(0, pad / 2, 0, pad)
        })
        root.addView(TextView(this).apply { text = "Cambiar el versículo:" })

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val saved = VerseRepository.intervalMinutes(this)
        spinner.setSelection(minutes.indexOf(saved).coerceAtLeast(2))
        var first = true
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                VerseRepository.setIntervalMinutes(this@MainActivity, minutes[pos])
                Scheduler.schedule(this@MainActivity)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner)

        root.addView(TextView(this).apply {
            text = "Tamaño de letra:"
            setPadding(0, pad, 0, 0)
        })
        val sizeSpinner = Spinner(this)
        sizeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sizeLabels)
        sizeSpinner.setSelection(sizes.indexOf(VerseRepository.textSizeSp(this)).coerceAtLeast(2))
        var firstSize = true
        sizeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (firstSize) { firstSize = false; return }
                VerseRepository.setTextSizeSp(this@MainActivity, sizes[pos])
                VerseWidget.refreshAll(this@MainActivity)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sizeSpinner)

        root.addView(Button(this).apply {
            text = "Cambiar versículo ahora"
            setOnClickListener {
                VerseRepository.next(this@MainActivity)
                VerseWidget.refreshAll(this@MainActivity)
            }
        })

        setContentView(root)
    }
}
