package com.example.versiculos

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.FileOutputStream
import kotlin.math.max

class MainActivity : Activity() {

    private val labels = listOf(
        "Cada 15 minutos", "Cada 30 minutos", "Cada hora",
        "Cada 3 horas", "Cada 6 horas", "Cada 12 horas", "Cada día"
    )
    private val minutes = listOf(15L, 30L, 60L, 180L, 360L, 720L, 1440L)
    private val sizeLabels = listOf("Pequeña", "Mediana", "Grande", "Muy grande", "Enorme")
    private val sizes = listOf(16, 20, 24, 28, 34)
    private val palette = intArrayOf(
        0xFF1F2A44.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF424242.toInt(),
        0xFF1C4E9D.toInt(), 0xFF1B5E20.toInt(), 0xFF6D1B34.toInt(), 0xFF4A2C7A.toInt(),
        0xFF5D4037.toInt(), 0xFFF5C451.toInt(), 0xFFC9D3F2.toInt()
    )
    private val reqImage = 42

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun refresh() {
        VerseWidget.refreshAll(this)
    }

    private fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

    private fun header(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 18f
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, dp(24), 0, dp(6))
        return t
    }

    private fun spinnerRow(options: List<String>, selected: Int, onChange: (Int) -> Unit): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        s.setSelection(selected)
        var first = true
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) {
                    first = false
                    return
                }
                onChange(pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return s
    }

    private fun colorPicker(current: Int, onPick: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL

        val edit = EditText(this)
        edit.hint = "#RRGGBB"
        edit.setText(hex(current))
        edit.setSingleLine()
        edit.filters = arrayOf(InputFilter.LengthFilter(7))

        val row = LinearLayout(this)
        for (c in palette) {
            val dot = View(this)
            val lp = LinearLayout.LayoutParams(dp(40), dp(40))
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            dot.layoutParams = lp
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.OVAL
            shape.setColor(c)
            shape.setStroke(dp(2), 0xFF888888.toInt())
            dot.background = shape
            dot.setOnClickListener {
                edit.setText(hex(c))
                onPick(c)
            }
            row.addView(dot)
        }
        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        box.addView(scroll)

        val hexRow = LinearLayout(this)
        hexRow.orientation = LinearLayout.HORIZONTAL
        hexRow.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val apply = Button(this)
        apply.text = "Aplicar"
        apply.setOnClickListener {
            try {
                onPick(Color.parseColor(edit.text.toString().trim()))
            } catch (e: IllegalArgumentException) {
                Toast.makeText(this, "Color no válido. Usa el formato #RRGGBB", Toast.LENGTH_SHORT).show()
            }
        }
        hexRow.addView(apply)
        box.addView(hexRow)
        return box
    }

    private fun seekRow(title: String, current: Int, maxValue: Int, onDone: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val label = TextView(this)
        label.text = "$title: $current%"
        val bar = SeekBar(this)
        bar.max = maxValue
        bar.progress = current
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "$title: $p%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                onDone(bar.progress)
            }
        })
        box.addView(label)
        box.addView(bar)
        return box
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setPadding(0, dp(10), 0, 0)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(20), dp(20), dp(30))

        val title = TextView(this)
        title.text = "Versículos"
        title.textSize = 26f
        root.addView(title)
        root.addView(label(
            "Para añadir el widget: mantén presionado un espacio vacío de tu pantalla " +
                "de inicio → Widgets → Versículos. Toca el widget para cambiar de versículo al instante."
        ))

        // --- Cambio de versículo ---
        root.addView(header("Cambio de versículo"))
        root.addView(
            spinnerRow(labels, minutes.indexOf(VerseRepository.intervalMinutes(this)).coerceAtLeast(2)) { pos ->
                VerseRepository.setIntervalMinutes(this, minutes[pos])
                Scheduler.schedule(this)
            }
        )
        val nowBtn = Button(this)
        nowBtn.text = "Cambiar versículo ahora"
        nowBtn.setOnClickListener {
            VerseRepository.next(this)
            refresh()
        }
        root.addView(nowBtn)

        // --- Letra ---
        root.addView(header("Letra"))
        root.addView(label("Tamaño"))
        root.addView(
            spinnerRow(sizeLabels, sizes.indexOf(VerseRepository.textSizeSp(this)).coerceAtLeast(2)) { pos ->
                VerseRepository.setTextSizeSp(this, sizes[pos])
                refresh()
            }
        )
        root.addView(label("Color de la letra"))
        root.addView(colorPicker(VerseRepository.textColor(this)) { c ->
            VerseRepository.putInt(this, "text_color", c)
            refresh()
        })

        // --- Fondo ---
        root.addView(header("Fondo"))
        root.addView(label("Color de fondo"))
        root.addView(colorPicker(VerseRepository.bgColor(this)) { c ->
            VerseRepository.putInt(this, "bg_color", c)
            refresh()
        })
        root.addView(label(""))
        root.addView(seekRow("Opacidad del fondo", VerseRepository.bgOpacity(this), 100) { v ->
            VerseRepository.putInt(this, "bg_opacity", v)
            refresh()
        })

        val pickBtn = Button(this)
        pickBtn.text = "Elegir imagen de la galería"
        pickBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Elegir imagen"), reqImage)
        }
        root.addView(pickBtn)

        val clearBtn = Button(this)
        clearBtn.text = "Quitar imagen de fondo"
        clearBtn.setOnClickListener {
            VerseRepository.bgImageFile(this).delete()
            refresh()
        }
        root.addView(clearBtn)

        root.addView(seekRow("Oscurecer la imagen", VerseRepository.scrim(this), 80) { v ->
            VerseRepository.putInt(this, "scrim", v)
            refresh()
        })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqImage || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val ok = saveBackground(uri)
            runOnUiThread {
                if (ok) refresh()
                Toast.makeText(
                    this,
                    if (ok) "Imagen aplicada al widget" else "No se pudo usar esa imagen",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }.start()
    }

    /** Reduce la imagen elegida, corrige su rotación y la guarda dentro de la app. */
    private fun saveBackground(uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: throw IllegalStateException("sin imagen")

            val orientation = runCatching {
                contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                }
            }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees != 0f) {
                val m = Matrix()
                m.postRotate(degrees)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(VerseRepository.bgImageFile(this)).use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
