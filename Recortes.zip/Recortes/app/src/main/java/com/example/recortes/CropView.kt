package com.example.recortes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min

/** Muestra un fotograma con un recuadro de recorte libre que se arrastra por los bordes y esquinas. */
class CropView(ctx: Context) : View(ctx) {

    var bitmap: Bitmap? = null
        set(value) {
            field = value
            invalidate()
        }

    // Recuadro de recorte, en proporción de la imagen (0 a 1)
    var l = 0f
    var t = 0f
    var r = 1f
    var b = 1f

    var onChange: (() -> Unit)? = null

    private val density = ctx.resources.displayMetrics.density
    private val img = RectF()
    private val dimPaint = Paint().apply { color = 0xAA000000.toInt() }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66FFFFFF
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private val sideLeft = 1
    private val sideTop = 2
    private val sideRight = 4
    private val sideBottom = 8
    private val sideMove = 16
    private var mode = 0
    private var lastX = 0f
    private var lastY = 0f

    fun reset() {
        l = 0f
        t = 0f
        r = 1f
        b = 1f
        invalidate()
        onChange?.invoke()
    }

    fun setCrop(nl: Float, nt: Float, nr: Float, nb: Float) {
        l = nl
        t = nt
        r = nr
        b = nb
        invalidate()
        onChange?.invoke()
    }

    private fun fit(): Boolean {
        val bmp = bitmap ?: return false
        if (width == 0 || height == 0) return false
        val s = min(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val w = bmp.width * s
        val h = bmp.height * s
        img.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap
        if (bmp == null || !fit()) return
        canvas.drawBitmap(bmp, null, img, null)

        val cl = img.left + l * img.width()
        val cr = img.left + r * img.width()
        val ct = img.top + t * img.height()
        val cb = img.top + b * img.height()

        // Oscurece lo que se va a recortar
        canvas.drawRect(img.left, img.top, img.right, ct, dimPaint)
        canvas.drawRect(img.left, cb, img.right, img.bottom, dimPaint)
        canvas.drawRect(img.left, ct, cl, cb, dimPaint)
        canvas.drawRect(cr, ct, img.right, cb, dimPaint)

        // Cuadrícula de tercios y borde
        val w3 = (cr - cl) / 3f
        val h3 = (cb - ct) / 3f
        canvas.drawLine(cl + w3, ct, cl + w3, cb, gridPaint)
        canvas.drawLine(cl + 2 * w3, ct, cl + 2 * w3, cb, gridPaint)
        canvas.drawLine(cl, ct + h3, cr, ct + h3, gridPaint)
        canvas.drawLine(cl, ct + 2 * h3, cr, ct + 2 * h3, gridPaint)
        canvas.drawRect(cl, ct, cr, cb, linePaint)

        // Asas en esquinas y lados
        val cx = (cl + cr) / 2f
        val cy = (ct + cb) / 2f
        val rad = 7f * density
        val xs = floatArrayOf(cl, cx, cr)
        val ys = floatArrayOf(ct, cy, cb)
        for (xi in 0..2) {
            for (yi in 0..2) {
                if (xi == 1 && yi == 1) continue
                canvas.drawCircle(xs[xi], ys[yi], rad, handlePaint)
            }
        }
    }

    private fun hit(x: Float, y: Float): Int {
        val s = 30f * density
        val cl = img.left + l * img.width()
        val cr = img.left + r * img.width()
        val ct = img.top + t * img.height()
        val cb = img.top + b * img.height()
        val inH = x >= cl - s && x <= cr + s
        val inV = y >= ct - s && y <= cb + s
        val dl = abs(x - cl)
        val dr = abs(x - cr)
        val dt = abs(y - ct)
        val db = abs(y - cb)
        var m = 0
        if (inV) {
            if (dl <= s && dl <= dr) {
                m = m or sideLeft
            } else if (dr <= s) {
                m = m or sideRight
            }
        }
        if (inH) {
            if (dt <= s && dt <= db) {
                m = m or sideTop
            } else if (db <= s) {
                m = m or sideBottom
            }
        }
        if (m == 0 && x > cl && x < cr && y > ct && y < cb) m = sideMove
        return m
    }

    private fun drag(dx: Float, dy: Float) {
        val minSize = 0.05f
        if (mode == sideMove) {
            val w = r - l
            val h = b - t
            val nl = (l + dx).coerceIn(0f, 1f - w)
            val nt = (t + dy).coerceIn(0f, 1f - h)
            l = nl
            r = nl + w
            t = nt
            b = nt + h
            return
        }
        if ((mode and sideLeft) != 0) l = (l + dx).coerceIn(0f, r - minSize)
        if ((mode and sideRight) != 0) r = (r + dx).coerceIn(l + minSize, 1f)
        if ((mode and sideTop) != 0) t = (t + dy).coerceIn(0f, b - minSize)
        if ((mode and sideBottom) != 0) b = (b + dy).coerceIn(t + minSize, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled || bitmap == null || !fit()) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                mode = hit(e.x, e.y)
                lastX = e.x
                lastY = e.y
                return mode != 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 0) return false
                val dx = (e.x - lastX) / img.width()
                val dy = (e.y - lastY) / img.height()
                lastX = e.x
                lastY = e.y
                drag(dx, dy)
                invalidate()
                onChange?.invoke()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = 0
                return true
            }
        }
        return true
    }
}
