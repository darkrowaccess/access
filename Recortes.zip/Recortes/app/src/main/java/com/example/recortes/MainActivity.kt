package com.example.recortes

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.Crop
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val reqVideo = 1
    private var uri: Uri? = null
    private var retriever: MediaMetadataRetriever? = null
    private var vw = 0
    private var vh = 0
    private var durationMs = 0L
    private var frameToken = 0
    private var exporting = false
    private var transformer: Transformer? = null
    private var tempFile: File? = null
    private var savedUri: Uri? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()

    private lateinit var pickBtn: Button
    private lateinit var hint: TextView
    private lateinit var editor: LinearLayout
    private lateinit var cropView: CropView
    private lateinit var info: TextView
    private lateinit var frameBar: SeekBar
    private lateinit var detectBtn: Button
    private lateinit var resetBtn: Button
    private lateinit var exportBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var openBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))

        pickBtn = btn("Elegir video de la galería") { pickVideo() }
        root.addView(pickBtn)

        hint = TextView(this)
        hint.text = "Elige un video para empezar.\n\nPodrás arrastrar los lados y las esquinas del recuadro " +
            "para recortar a mano, o usar «Detectar bordes negros» para ajustarlo solo."
        hint.textSize = 15f
        hint.setPadding(dp(8), dp(24), dp(8), 0)
        root.addView(hint)

        editor = LinearLayout(this)
        editor.orientation = LinearLayout.VERTICAL
        editor.visibility = View.GONE

        cropView = CropView(this)
        cropView.onChange = { updateInfo() }
        editor.addView(cropView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        info = TextView(this)
        info.textSize = 14f
        info.setPadding(0, dp(8), 0, 0)
        editor.addView(info)

        val frameLabel = TextView(this)
        frameLabel.text = "Fotograma (elige uno claro para ver bien los bordes):"
        frameLabel.textSize = 13f
        frameLabel.setPadding(0, dp(8), 0, 0)
        editor.addView(frameLabel)

        frameBar = SeekBar(this)
        frameBar.max = 1000
        frameBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                showFrame(durationMs * frameBar.progress / 1000)
            }
        })
        editor.addView(frameBar)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        detectBtn = btn("Detectar bordes negros") { detectBorders() }
        resetBtn = btn("Restablecer") { cropView.reset() }
        row.addView(detectBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(resetBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        editor.addView(row)

        exportBtn = btn("Recortar y guardar") { startExport() }
        editor.addView(exportBtn)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.visibility = View.GONE
        editor.addView(progress)

        status = TextView(this)
        status.textSize = 14f
        status.setPadding(0, dp(4), 0, dp(4))
        editor.addView(status)

        cancelBtn = btn("Cancelar") { cancelExport() }
        cancelBtn.visibility = View.GONE
        editor.addView(cancelBtn)

        openBtn = btn("Ver el video recortado") { openResult() }
        openBtn.visibility = View.GONE
        editor.addView(openBtn)

        root.addView(editor, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    // ---------- Elegir y cargar el video ----------

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "video/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Elegir video"), reqVideo)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqVideo || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        loadVideo(u)
    }

    private fun loadVideo(u: Uri) {
        retriever?.release()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, u)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir ese video", Toast.LENGTH_SHORT).show()
            return
        }
        val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        if (w <= 0 || h <= 0) {
            Toast.makeText(this, "No se pudo leer el tamaño del video", Toast.LENGTH_SHORT).show()
            r.release()
            return
        }
        if (rot == 90 || rot == 270) {
            vw = h
            vh = w
        } else {
            vw = w
            vh = h
        }
        retriever = r
        uri = u
        savedUri = null
        frameBar.progress = 0
        cropView.reset()
        hint.visibility = View.GONE
        editor.visibility = View.VISIBLE
        openBtn.visibility = View.GONE
        status.text = ""
        updateInfo()
        showFrame(0)
    }

    private fun showFrame(ms: Long) {
        val r = retriever ?: return
        val token = ++frameToken
        executor.execute {
            var bmp: Bitmap? = null
            try {
                val raw = r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (raw != null) {
                    val m = max(raw.width, raw.height)
                    bmp = if (m > 1280) {
                        val s = 1280f / m
                        Bitmap.createScaledBitmap(raw, (raw.width * s).toInt(), (raw.height * s).toInt(), true)
                    } else {
                        raw
                    }
                }
            } catch (e: Throwable) {
                bmp = null
            }
            runOnUiThread {
                if (token == frameToken && bmp != null) cropView.bitmap = bmp
            }
        }
    }

    // ---------- Recorte ----------

    private class PxCrop(val x: Int, val y: Int, val w: Int, val h: Int)

    /** Recorte en píxeles del video, con medidas pares para que el codificador no falle. */
    private fun pixelCrop(): PxCrop {
        val maxW = (vw / 2) * 2
        val maxH = (vh / 2) * 2
        var w = (((cropView.r - cropView.l) * vw).roundToInt() / 2) * 2
        var h = (((cropView.b - cropView.t) * vh).roundToInt() / 2) * 2
        w = min(max(w, 16), maxW)
        h = min(max(h, 16), maxH)
        var x = ((cropView.l * vw).roundToInt() / 2) * 2
        var y = ((cropView.t * vh).roundToInt() / 2) * 2
        x = (min(x, vw - w) / 2) * 2
        y = (min(y, vh - h) / 2) * 2
        return PxCrop(max(x, 0), max(y, 0), w, h)
    }

    private fun updateInfo() {
        if (vw == 0) return
        val c = pixelCrop()
        info.text = "Original: ${vw}×${vh}   →   Recorte: ${c.w}×${c.h}"
    }

    private fun detectBorders() {
        val bmp = cropView.bitmap
        if (bmp == null) {
            Toast.makeText(this, "Espera a que cargue el fotograma", Toast.LENGTH_SHORT).show()
            return
        }
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val rowHits = IntArray(h)
        val colHits = IntArray(w)
        for (y in 0 until h) {
            val o = y * w
            for (x in 0 until w) {
                val c = px[o + x]
                val lum = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (lum > 30) {
                    rowHits[y]++
                    colHits[x]++
                }
            }
        }
        val rowMin = max(2, (w * 0.02f).toInt())
        val colMin = max(2, (h * 0.02f).toInt())
        var top = 0
        while (top < h && rowHits[top] < rowMin) top++
        var bottom = h - 1
        while (bottom > top && rowHits[bottom] < rowMin) bottom--
        var left = 0
        while (left < w && colHits[left] < colMin) left++
        var right = w - 1
        while (right > left && colHits[right] < colMin) right--

        if (top >= h || left >= w || bottom - top < 8 || right - left < 8) {
            Toast.makeText(this, "No se detectaron bordes. Prueba con otro fotograma más claro.", Toast.LENGTH_LONG).show()
            return
        }
        val inset = 2
        val il = if (left > 0) left + inset else 0
        val iy = if (top > 0) top + inset else 0
        val ir = if (right < w - 1) right - inset else w - 1
        val ib = if (bottom < h - 1) bottom - inset else h - 1
        if (ir - il < 8 || ib - iy < 8) return
        cropView.setCrop(
            il.toFloat() / w,
            iy.toFloat() / h,
            (ir + 1).toFloat() / w,
            (ib + 1).toFloat() / h
        )
    }

    // ---------- Exportar ----------

    private fun setExporting(on: Boolean) {
        exporting = on
        pickBtn.isEnabled = !on
        detectBtn.isEnabled = !on
        resetBtn.isEnabled = !on
        exportBtn.isEnabled = !on
        frameBar.isEnabled = !on
        cropView.isEnabled = !on
        progress.visibility = if (on) View.VISIBLE else View.GONE
        cancelBtn.visibility = if (on) View.VISIBLE else View.GONE
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private val poll = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val state = t.getProgress(progressHolder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                progress.isIndeterminate = false
                progress.progress = progressHolder.progress
                status.text = "Procesando… ${progressHolder.progress}%"
            } else {
                progress.isIndeterminate = true
                status.text = "Procesando…"
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun startExport() {
        val src = uri ?: return
        if (exporting) return
        val c = pixelCrop()
        // Coordenadas del recorte para el efecto: de -1 a 1, con el eje vertical hacia arriba
        val left = c.x.toFloat() / vw * 2f - 1f
        val right = (c.x + c.w).toFloat() / vw * 2f - 1f
        val top = 1f - c.y.toFloat() / vh * 2f
        val bottom = 1f - (c.y + c.h).toFloat() / vh * 2f

        val out = File(cacheDir, "recorte_tmp.mp4")
        out.delete()
        tempFile = out

        val effects = Effects(emptyList<AudioProcessor>(), listOf<Effect>(Crop(left, right, bottom, top)))
        val item = EditedMediaItem.Builder(MediaItem.fromUri(src)).setEffects(effects).build()

        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacks(poll)
                    status.text = "Guardando en la galería…"
                    executor.execute {
                        val saved = saveToGallery(out)
                        runOnUiThread {
                            out.delete()
                            setExporting(false)
                            if (saved != null) {
                                savedUri = saved
                                status.text = "Listo. Guardado en Galería → carpeta «Recortes» (Películas/Recortes)."
                                openBtn.visibility = View.VISIBLE
                            } else {
                                status.text = "El video se recortó, pero no se pudo guardar en la galería."
                            }
                        }
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacks(poll)
                    out.delete()
                    setExporting(false)
                    status.text = "No se pudo procesar el video: ${exportException.message}"
                }
            })
            .build()
        transformer = t

        openBtn.visibility = View.GONE
        progress.progress = 0
        status.text = "Procesando…"
        setExporting(true)
        t.start(item, out.absolutePath)
        handler.post(poll)
    }

    private fun cancelExport() {
        handler.removeCallbacks(poll)
        try { transformer?.cancel() } catch (e: Exception) { }
        tempFile?.delete()
        setExporting(false)
        status.text = "Cancelado."
    }

    private fun saveToGallery(file: File): Uri? {
        val name = "Recorte_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues()
        values.put(MediaStore.Video.Media.DISPLAY_NAME, name)
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Recortes")
        values.put(MediaStore.Video.Media.IS_PENDING, 1)
        val resolver = contentResolver
        val dest = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(dest)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            val done = ContentValues()
            done.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(dest, done, null, null)
            dest
        } catch (e: Exception) {
            resolver.delete(dest, null, null)
            null
        }
    }

    private fun openResult() {
        val u = savedUri ?: return
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(u, "video/mp4")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No hay una app para abrir el video", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(poll)
        try { transformer?.cancel() } catch (e: Exception) { }
        retriever?.release()
        executor.shutdown()
    }
}
