package com.example.musica

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Song(val id: Long, val title: String, val artist: String, val duration: Long) {
    val uri: Uri
        get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    val artistLabel: String
        get() = if (artist.isBlank()) "Artista desconocido" else artist
}

/** Canciones de música que hay en el dispositivo. */
object Library {
    var songs: List<Song> = emptyList()
        private set

    fun load(ctx: Context) {
        val list = ArrayList<Song>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 5000"
        val order = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null, order
            )?.use { c ->
                while (c.moveToNext()) {
                    val artist = c.getString(2)
                    list.add(
                        Song(
                            c.getLong(0),
                            c.getString(1) ?: "Sin título",
                            if (artist == null || artist == "<unknown>") "" else artist,
                            c.getLong(3)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // sin permiso o sin acceso: la lista queda vacía
        }
        songs = list
    }

    fun byId(id: Long): Song? = songs.firstOrNull { it.id == id }
}
