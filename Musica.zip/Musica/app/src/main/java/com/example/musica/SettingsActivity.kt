package com.example.musica

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast

class SettingsActivity : BaseActivity() {

    private val reqBg = 21

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(16), ui.dp(24), ui.dp(16), ui.dp(16))

        content.addView(ui.text("Personalizar", 24f, Color.WHITE, true))
        val hint = ui.text(
            "Elige una imagen de tu galería como fondo de toda la app. " +
                "Cada lista también puede tener su propia portada, desde la pantalla de la lista.",
            14f, GRAY, false
        )
        hint.setPadding(0, ui.dp(8), 0, ui.dp(16))
        content.addView(hint)

        content.addView(ui.flat("Elegir imagen de fondo de la galería") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Elegir imagen"), reqBg)
        })
        content.addView(ui.flat("Quitar imagen de fondo") {
            Settings.bgFile(this).delete()
            backdrop.refresh()
        })
        content.addView(ui.seekRow("Oscurecer la imagen", Settings.dim(this), 95) { v ->
            Settings.setDim(this, v)
            backdrop.refresh()
        })

        show(content)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqBg || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val ok = ImageUtil.saveFromUri(this, uri, Settings.bgFile(this))
            runOnUiThread {
                if (ok) backdrop.refresh()
                else Toast.makeText(this, "No se pudo usar esa imagen", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}
