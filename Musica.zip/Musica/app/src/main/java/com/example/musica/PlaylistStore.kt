package com.example.musica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Playlist(
    val id: Long,
    var name: String,
    var songIds: MutableList<Long> = mutableListOf()
)

object PlaylistStore {
    private const val FILE = "playlists.json"

    private fun load(ctx: Context): MutableList<Playlist> {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            val out = mutableListOf<Playlist>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ids = mutableListOf<Long>()
                val s = o.optJSONArray("songs")
                if (s != null) for (j in 0 until s.length()) ids.add(s.getLong(j))
                out.add(Playlist(o.getLong("id"), o.optString("name", "Lista"), ids))
            }
            out
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun save(ctx: Context, list: List<Playlist>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            val s = JSONArray()
            for (id in p.songIds) s.put(id)
            o.put("songs", s)
            arr.put(o)
        }
        File(ctx.filesDir, FILE).writeText(arr.toString())
    }

    fun all(ctx: Context): List<Playlist> = load(ctx).sortedBy { it.name.lowercase() }

    fun get(ctx: Context, id: Long): Playlist? = load(ctx).firstOrNull { it.id == id }

    fun upsert(ctx: Context, p: Playlist) {
        val list = load(ctx)
        val i = list.indexOfFirst { it.id == p.id }
        if (i >= 0) list[i] = p else list.add(p)
        save(ctx, list)
    }

    fun delete(ctx: Context, id: Long) {
        val list = load(ctx)
        list.removeAll { it.id == id }
        save(ctx, list)
        coverFile(ctx, id).delete()
    }

    fun coverFile(ctx: Context, id: Long): File = File(ctx.filesDir, "cover_$id.jpg")
}

/** Portadas de las listas (imágenes elegidas de la galería). */
object Covers {
    private val cache = HashMap<String, Bitmap?>()

    fun bitmap(ctx: Context, id: Long, sample: Int): Bitmap? {
        val f = PlaylistStore.coverFile(ctx, id)
        if (!f.exists()) return null
        val key = "${id}_${f.lastModified()}_$sample"
        if (cache.containsKey(key)) return cache[key]
        val o = BitmapFactory.Options()
        o.inSampleSize = sample
        val bmp = BitmapFactory.decodeFile(f.path, o)
        cache[key] = bmp
        return bmp
    }
}

object Settings {
    private const val PREFS = "musica_prefs"

    fun bgFile(ctx: Context): File = File(ctx.filesDir, "bg.jpg")

    fun dim(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("dim", 60)

    fun setDim(ctx: Context, v: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("dim", v).apply()
    }
}
