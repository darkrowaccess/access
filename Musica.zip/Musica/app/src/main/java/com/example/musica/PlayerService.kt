package com.example.musica

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Build
import android.os.IBinder

/** Mantiene la música sonando con la pantalla apagada y muestra los controles en la notificación. */
class PlayerService : Service() {

    companion object {
        const val A_TOGGLE = "com.example.musica.TOGGLE"
        const val A_NEXT = "com.example.musica.NEXT"
        const val A_PREV = "com.example.musica.PREV"
        const val A_CLOSE = "com.example.musica.CLOSE"
    }

    private val listener: () -> Unit = { Notifier.update(this) }

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) Player.pause()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Player.listeners.add(listener)
        val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(noisy, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(noisy, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_TOGGLE -> Player.toggle()
            A_NEXT -> Player.next()
            A_PREV -> Player.previous()
            A_CLOSE -> {
                Player.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        startForeground(Notifier.ID, Notifier.build(this))
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Player.listeners.remove(listener)
        try { unregisterReceiver(noisy) } catch (e: Exception) { }
        super.onDestroy()
    }
}

object Notifier {
    const val ID = 1
    private const val CHANNEL = "musica"

    private fun action(ctx: Context, icon: Int, label: String, action: String, code: Int): Notification.Action {
        val pi = PendingIntent.getService(
            ctx, code,
            Intent(ctx, PlayerService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(ctx, icon), label, pi).build()
    }

    fun build(ctx: Context): Notification {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Reproducción", NotificationManager.IMPORTANCE_LOW)
        )
        val song = Player.current
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val playIcon = if (Player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playLabel = if (Player.isPlaying) "Pausar" else "Reproducir"
        return Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(song?.title ?: "Música")
            .setContentText(song?.artistLabel ?: "")
            .setContentIntent(open)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(ctx, android.R.drawable.ic_media_previous, "Anterior", PlayerService.A_PREV, 1))
            .addAction(action(ctx, playIcon, playLabel, PlayerService.A_TOGGLE, 2))
            .addAction(action(ctx, android.R.drawable.ic_media_next, "Siguiente", PlayerService.A_NEXT, 3))
            .addAction(action(ctx, android.R.drawable.ic_menu_close_clear_cancel, "Cerrar", PlayerService.A_CLOSE, 4))
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    fun update(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).notify(ID, build(ctx))
    }
}
