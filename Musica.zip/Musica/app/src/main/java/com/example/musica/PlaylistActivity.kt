package com.example.musica

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class PlaylistActivity : BaseActivity() {

    private var playlistId = -1L
    private var songs: List<Song> = emptyList()
    private lateinit var cover: ImageView
    private lateinit var nameText: TextView
    private lateinit var countText: TextView
    private lateinit var list: ListView
    private val adapter = SongAdapter()
    private val reqCover = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playlistId = intent.getLongExtra("playlist_id", -1L)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(8), ui.dp(16), ui.dp(8), 0)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(ui.dp(8), 0, ui.dp(8), ui.dp(8))
        cover = ImageView(this)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        val cbg = GradientDrawable()
        cbg.cornerRadius = ui.dp(12).toFloat()
        cbg.setColor(0xFF1C1C1C.toInt())
        cover.background = cbg
        cover.clipToOutline = true
        val clp = LinearLayout.LayoutParams(ui.dp(96), ui.dp(96))
        clp.rightMargin = ui.dp(16)
        header.addView(cover, clp)
        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        nameText = ui.text("", 22f, Color.WHITE, true)
        countText = ui.text("", 14f, GRAY, false)
        info.addView(nameText)
        info.addView(countText)
        header.addView(info)
        content.addView(header)

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.addView(ui.flat("Reproducir") {
            if (songs.isEmpty()) {
                Toast.makeText(this, "La lista está vacía", Toast.LENGTH_SHORT).show()
            } else {
                Player.play(this, songs, 0, playlistId)
                startActivity(Intent(this, PlayerActivity::class.java))
            }
        })
        actions.addView(ui.flat("Agregar canciones") {
            val i = Intent(this, SongPickerActivity::class.java)
            i.putExtra("playlist_id", playlistId)
            startActivity(i)
        })
        actions.addView(ui.flat("Portada") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "Elegir imagen"), reqCover)
        })
        actions.addView(ui.flat("Quitar portada") {
            PlaylistStore.coverFile(this, playlistId).delete()
            reload()
        })
        actions.addView(ui.flat("Renombrar") {
            val p = PlaylistStore.get(this, playlistId)
            if (p != null) {
                ui.askName("Renombrar lista", p.name) { name ->
                    p.name = name
                    PlaylistStore.upsert(this, p)
                    reload()
                }
            }
        })
        actions.addView(ui.flat("Eliminar") {
            ui.confirm("¿Eliminar esta lista?", "Eliminar") {
                PlaylistStore.delete(this, playlistId)
                finish()
            }
        })
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(actions)
        content.addView(scroll)

        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            Player.play(this, songs, position, playlistId)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        list.setOnItemLongClickListener { _, _, position, _ ->
            val s = songs[position]
            ui.confirm("¿Quitar «${s.title}» de la lista?", "Quitar") {
                val p = PlaylistStore.get(this, playlistId)
                if (p != null) {
                    p.songIds.remove(s.id)
                    PlaylistStore.upsert(this, p)
                    reload()
                }
            }
            true
        }
        content.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        show(content)
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        val p = PlaylistStore.get(this, playlistId)
        if (p == null) {
            finish()
            return
        }
        if (Library.songs.isEmpty()) Library.load(this)
        songs = p.songIds.mapNotNull { Library.byId(it) }
        nameText.text = p.name
        countText.text = "${songs.size} canciones"
        val bmp = Covers.bitmap(this, playlistId, 2)
        if (bmp != null) cover.setImageBitmap(bmp) else cover.setImageDrawable(null)
        adapter.notifyDataSetChanged()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCover || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val ok = ImageUtil.saveFromUri(this, uri, PlaylistStore.coverFile(this, playlistId))
            runOnUiThread {
                if (ok) reload()
                else Toast.makeText(this, "No se pudo usar esa imagen", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private inner class SongAdapter : BaseAdapter() {
        override fun getCount(): Int = songs.size
        override fun getItem(position: Int): Any = songs[position]
        override fun getItemId(position: Int): Long = songs[position].id
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val s = songs[position]
            return ui.row(s.title, s.artistLabel)
        }
    }
}
