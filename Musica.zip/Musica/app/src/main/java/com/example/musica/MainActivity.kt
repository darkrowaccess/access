package com.example.musica

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : BaseActivity() {

    private var tab = 0
    private lateinit var list: ListView
    private lateinit var tabSongs: TextView
    private lateinit var tabLists: TextView
    private lateinit var newList: TextView
    private lateinit var searchBox: android.widget.EditText
    private var shown: List<Song> = emptyList()
    private lateinit var emptyText: TextView
    private lateinit var permBox: LinearLayout
    private lateinit var mini: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniBtn: TextView

    private val songsAdapter = SongsAdapter()
    private val listsAdapter = ListsAdapter()
    private val reqPerm = 100
    private val changeListener: () -> Unit = { updateMini() }

    private fun needed(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasPermission(): Boolean =
        needed().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun askPermission() {
        val perms = ArrayList<String>(needed().toList())
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), reqPerm)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), 0)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        tabSongs = ui.flat("Canciones") { setTab(0) }
        tabLists = ui.flat("Listas") { setTab(1) }
        tabSongs.textSize = 20f
        tabLists.textSize = 20f
        top.addView(tabSongs)
        top.addView(tabLists)
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(ui.flat("⚙") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        content.addView(top)

        newList = ui.flat("+  Nueva lista") {
            ui.askName("Nueva lista", "") { name ->
                val p = Playlist(System.currentTimeMillis(), name)
                PlaylistStore.upsert(this, p)
                val i = Intent(this, PlaylistActivity::class.java)
                i.putExtra("playlist_id", p.id)
                startActivity(i)
            }
        }
        newList.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        content.addView(newList)

        searchBox = ui.searchBar { applyFilter() }
        content.addView(searchBox)

        permBox = LinearLayout(this)
        permBox.orientation = LinearLayout.VERTICAL
        permBox.setPadding(ui.dp(16), ui.dp(24), ui.dp(16), ui.dp(24))
        permBox.addView(
            ui.text(
                "Necesito acceso a tu música para mostrar tus canciones.\n" +
                    "Si no aparece la ventana de permiso, actívalo en Ajustes → Aplicaciones → Música → Permisos.",
                15f, Color.WHITE, false
            )
        )
        permBox.addView(ui.flat("Dar permiso") { askPermission() })
        permBox.visibility = View.GONE
        content.addView(permBox)

        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.setOnItemClickListener { _, _, position, _ ->
            if (tab == 0) {
                Player.play(this, shown, position, -1L)
                startActivity(Intent(this, PlayerActivity::class.java))
            } else {
                val p = listsAdapter.items[position]
                val i = Intent(this, PlaylistActivity::class.java)
                i.putExtra("playlist_id", p.id)
                startActivity(i)
            }
        }
        content.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        emptyText = ui.text("", 15f, GRAY, false)
        emptyText.gravity = Gravity.CENTER
        emptyText.setPadding(ui.dp(24), ui.dp(48), ui.dp(24), ui.dp(24))
        content.addView(
            emptyText,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
        )
        list.emptyView = emptyText

        // Mini reproductor
        mini = LinearLayout(this)
        mini.orientation = LinearLayout.HORIZONTAL
        mini.gravity = Gravity.CENTER_VERTICAL
        mini.setBackgroundColor(0xFF121212.toInt())
        mini.setPadding(ui.dp(16), 0, ui.dp(4), 0)
        miniTitle = ui.text("", 15f, Color.WHITE, true)
        miniTitle.maxLines = 1
        miniTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        mini.addView(miniTitle, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        miniBtn = ui.flat("▶") { Player.toggle() }
        miniBtn.textSize = 20f
        mini.addView(miniBtn)
        mini.setOnClickListener { startActivity(Intent(this, PlayerActivity::class.java)) }
        mini.visibility = View.GONE
        content.addView(mini, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ui.dp(56)))

        setTab(0)
        show(content)

        if (!hasPermission()) askPermission()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshLibrary()
    }

    override fun onResume() {
        super.onResume()
        Player.listeners.add(changeListener)
        refreshLibrary()
        updateMini()
    }

    override fun onPause() {
        super.onPause()
        Player.listeners.remove(changeListener)
    }

    private fun refreshLibrary() {
        val ok = hasPermission()
        permBox.visibility = if (ok) View.GONE else View.VISIBLE
        if (ok) Library.load(this)
        listsAdapter.items = PlaylistStore.all(this)
        applyFilter()
        listsAdapter.notifyDataSetChanged()
    }

    private fun applyFilter() {
        shown = Library.search(searchBox.text.toString())
        songsAdapter.notifyDataSetChanged()
    }

    private fun setTab(i: Int) {
        tab = i
        tabSongs.setTextColor(if (i == 0) Color.WHITE else GRAY)
        tabLists.setTextColor(if (i == 1) Color.WHITE else GRAY)
        newList.visibility = if (i == 1) View.VISIBLE else View.GONE
        searchBox.visibility = if (i == 0) View.VISIBLE else View.GONE
        emptyText.text = if (i == 0) "No se encontraron canciones en el dispositivo."
        else "Aún no tienes listas.\nToca «+ Nueva lista» para crear la primera."
        list.adapter = if (i == 0) songsAdapter else listsAdapter
    }

    private fun updateMini() {
        val s = Player.current
        mini.visibility = if (s == null) View.GONE else View.VISIBLE
        miniTitle.text = s?.title ?: ""
        miniBtn.text = if (Player.isPlaying) "||" else "▶"
    }

    private inner class SongsAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = shown[position].id
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val s = shown[position]
            return ui.row(s.title, s.artistLabel)
        }
    }

    private inner class ListsAdapter : BaseAdapter() {
        var items: List<Playlist> = emptyList()
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = items[position].id
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val p = items[position]
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8))

            val iv = ImageView(this@MainActivity)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            val bg = GradientDrawable()
            bg.cornerRadius = ui.dp(8).toFloat()
            bg.setColor(0xFF1C1C1C.toInt())
            iv.background = bg
            iv.clipToOutline = true
            val bmp = Covers.bitmap(this@MainActivity, p.id, 4)
            if (bmp != null) iv.setImageBitmap(bmp)
            val lp = LinearLayout.LayoutParams(ui.dp(52), ui.dp(52))
            lp.rightMargin = ui.dp(14)
            row.addView(iv, lp)

            val col = LinearLayout(this@MainActivity)
            col.orientation = LinearLayout.VERTICAL
            col.addView(ui.text(p.name, 16f, Color.WHITE, false))
            col.addView(ui.text("${p.songIds.size} canciones", 13f, GRAY, false))
            row.addView(col)
            return row
        }
    }
}
