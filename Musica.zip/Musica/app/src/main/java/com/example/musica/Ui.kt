package com.example.musica

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.FrameLayout
import android.widget.ImageView
import android.graphics.BitmapFactory

const val GRAY = 0xFF9E9E9E.toInt()

class Ui(private val ctx: Context) {

    fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun time(ms: Int): String = String.format("%d:%02d", ms / 60000, (ms / 1000) % 60)

    fun text(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        return v
    }

    /** Botón de texto plano, sin caja, estilo minimalista. */
    fun flat(label: String, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = label
        t.textSize = 15f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(12), dp(12), dp(12))
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        t.setBackgroundResource(tv.resourceId)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    /** Fila con título y subtítulo para las listas de canciones. */
    fun row(title: String, subtitle: String): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(10), dp(16), dp(10))
        val t = text(title, 16f, Color.WHITE, false)
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        box.addView(t)
        val s = text(subtitle, 13f, GRAY, false)
        s.maxLines = 1
        s.ellipsize = android.text.TextUtils.TruncateAt.END
        box.addView(s)
        return box
    }

    fun askName(title: String, initial: String, onOk: (String) -> Unit) {
        val e = EditText(ctx)
        e.setText(initial)
        e.setSingleLine()
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(e)
            .setPositiveButton("Aceptar") { _, _ ->
                val t = e.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    fun confirm(title: String, ok: String, onOk: () -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setPositiveButton(ok) { _, _ -> onOk() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    fun whiteSeek(bar: SeekBar) {
        bar.progressTintList = ColorStateList.valueOf(Color.WHITE)
        bar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
    }

    fun seekRow(title: String, current: Int, maxValue: Int, onDone: (Int) -> Unit): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val label = text("$title: $current%", 15f, Color.WHITE, false)
        label.setPadding(dp(12), dp(16), dp(12), 0)
        val bar = SeekBar(ctx)
        whiteSeek(bar)
        bar.max = maxValue
        bar.progress = current
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "$title: $p%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                onDone(bar.progress)
            }
        })
        box.addView(label)
        box.addView(bar)
        return box
    }
}

/** Fondo negro de todas las pantallas; puede llevar una imagen de la galería oscurecida. */
class Backdrop(ctx: Context) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    private val dim = View(ctx)

    init {
        setBackgroundColor(Color.BLACK)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(img, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(dim, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    fun refresh() {
        val f = Settings.bgFile(context)
        if (f.exists()) {
            img.setImageBitmap(BitmapFactory.decodeFile(f.path))
            dim.setBackgroundColor(Color.argb(Settings.dim(context) * 255 / 100, 0, 0, 0))
        } else {
            img.setImageDrawable(null)
            dim.setBackgroundColor(Color.TRANSPARENT)
        }
    }
}
