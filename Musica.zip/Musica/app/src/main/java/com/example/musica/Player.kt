package com.example.musica

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.PowerManager

/** Reproductor único de la app: cola de canciones, reproducir, pausar, siguiente y anterior. */
object Player {
    private var mp: MediaPlayer? = null
    private var app: Context? = null
    private var focusReq: AudioFocusRequest? = null

    var queue: List<Song> = emptyList()
        private set
    var index = -1
        private set
    var isPlaying = false
        private set
    /** Lista de la que viene la cola (-1 si son todas las canciones). */
    var sourcePlaylist = -1L
        private set

    /** Quien quiera enterarse de los cambios (pantallas, notificación). */
    val listeners = mutableListOf<() -> Unit>()

    val current: Song?
        get() = queue.getOrNull(index)

    val position: Int
        get() = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }

    val duration: Int
        get() = try { mp?.duration ?: (current?.duration?.toInt() ?: 0) } catch (e: Exception) { 0 }

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .build()

    private fun changed() {
        for (l in listeners.toList()) l()
    }

    fun play(ctx: Context, songs: List<Song>, start: Int, playlistId: Long) {
        app = ctx.applicationContext
        queue = songs
        index = start
        sourcePlaylist = playlistId
        startCurrent()
    }

    private fun startCurrent() {
        val c = app ?: return
        val song = current ?: return
        release()
        try {
            val m = MediaPlayer()
            m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            m.setAudioAttributes(attrs)
            m.setDataSource(c, song.uri)
            m.setOnCompletionListener { onCompleted() }
            m.setOnErrorListener { _, _, _ ->
                isPlaying = false
                changed()
                true
            }
            m.prepare()
            requestFocus()
            m.start()
            mp = m
            isPlaying = true
        } catch (e: Exception) {
            isPlaying = false
        }
        c.startForegroundService(Intent(c, PlayerService::class.java))
        changed()
    }

    private fun onCompleted() {
        if (index + 1 < queue.size) {
            index++
            startCurrent()
        } else {
            try { mp?.seekTo(0) } catch (e: Exception) { }
            isPlaying = false
            changed()
        }
    }

    fun toggle() {
        if (isPlaying) pause() else resume()
    }

    fun pause() {
        try { if (mp?.isPlaying == true) mp?.pause() } catch (e: Exception) { }
        isPlaying = false
        changed()
    }

    fun resume() {
        val m = mp ?: return
        if (requestFocus()) {
            try { m.start() } catch (e: Exception) { }
            isPlaying = true
            changed()
        }
    }

    fun next() {
        if (queue.isEmpty()) return
        index = (index + 1) % queue.size
        startCurrent()
    }

    fun previous() {
        if (queue.isEmpty()) return
        if (position > 3000) {
            seekTo(0)
            return
        }
        index = (index - 1 + queue.size) % queue.size
        startCurrent()
    }

    fun seekTo(ms: Int) {
        try { mp?.seekTo(ms) } catch (e: Exception) { }
        changed()
    }

    fun stop() {
        release()
        abandonFocus()
        queue = emptyList()
        index = -1
        isPlaying = false
        changed()
    }

    private fun release() {
        try { mp?.release() } catch (e: Exception) { }
        mp = null
    }

    private fun requestFocus(): Boolean {
        val c = app ?: return false
        val am = c.getSystemService(AudioManager::class.java)
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS ||
                    change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT
                ) pause()
            }
            .build()
        focusReq = req
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val c = app ?: return
        val req = focusReq ?: return
        c.getSystemService(AudioManager::class.java).abandonAudioFocusRequest(req)
    }
}
