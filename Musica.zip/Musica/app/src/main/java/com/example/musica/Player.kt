package com.example.musica

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.PowerManager

/** Reproductor único de la app: cola de canciones, reproducir, pausar, siguiente y anterior. */
object Player {
    private var mp: MediaPlayer? = null
    private var app: Context? = null
    private var resumeOnGain = false

    var queue: List<Song> = emptyList()
        private set
    var index = -1
        private set
    var isPlaying = false
        private set
    /** Modo de repetición: REPEAT_OFF, REPEAT_ALL (toda la lista) o REPEAT_ONE (una canción). */
    const val REPEAT_OFF = 0
    const val REPEAT_ALL = 1
    const val REPEAT_ONE = 2
    var repeatMode = REPEAT_OFF
        private set

    /** Lista de la que viene la cola (-1 si son todas las canciones). */
    var sourcePlaylist = -1L
        private set

    /** Quien quiera enterarse de los cambios (pantallas, notificación). */
    val listeners = mutableListOf<() -> Unit>()

    val current: Song?
        get() = queue.getOrNull(index)

    val position: Int
        get() = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }

    val duration: Int
        get() = try { mp?.duration ?: (current?.duration?.toInt() ?: 0) } catch (e: Exception) { 0 }

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .build()

    // Un solo "pedido" de audio que se reutiliza siempre. Si se creara uno nuevo cada vez,
    // el sistema le avisaría al anterior que perdió el foco y la música se pausaría sola.
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            resumeOnGain = false
            pause()
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            resumeOnGain = isPlaying
            pause()
        } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
            if (resumeOnGain) {
                resumeOnGain = false
                resume()
            }
        }
    }

    private val focusRequest: AudioFocusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener)
            .build()
    }

    private fun changed() {
        for (l in listeners.toList()) l()
    }

    fun play(ctx: Context, songs: List<Song>, start: Int, playlistId: Long) {
        app = ctx.applicationContext
        queue = songs
        index = start
        sourcePlaylist = playlistId
        startCurrent()
    }

    private fun startCurrent(attempts: Int = 0) {
        val c = app ?: return
        if (current == null) return
        release()
        var started = false
        try {
            val m = MediaPlayer()
            mp = m
            m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            m.setAudioAttributes(attrs)
            m.setDataSource(c, current!!.uri)
            m.setOnCompletionListener { onCompleted() }
            m.setOnErrorListener { _, _, _ ->
                release()
                isPlaying = false
                changed()
                true
            }
            m.prepare()
            requestFocus()
            m.start()
            started = true
        } catch (e: Exception) {
            release()
        }
        // Si una canción no se puede abrir, se salta a la siguiente
        if (!started && attempts + 1 < queue.size) {
            index = (index + 1) % queue.size
            startCurrent(attempts + 1)
            return
        }
        isPlaying = started
        resumeOnGain = false
        c.startForegroundService(Intent(c, PlayerService::class.java))
        changed()
    }

    /** Cambia entre: sin repetir → repetir lista → repetir una canción. */
    fun cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3
        changed()
    }

    private fun onCompleted() {
        if (repeatMode == REPEAT_ONE) {
            startCurrent()
        } else if (index + 1 < queue.size) {
            index++
            startCurrent()
        } else if (repeatMode == REPEAT_ALL && queue.isNotEmpty()) {
            index = 0
            startCurrent()
        } else {
            try { mp?.seekTo(0) } catch (e: Exception) { }
            isPlaying = false
            changed()
        }
    }

    private fun reallyPlaying(): Boolean =
        try { mp?.isPlaying == true } catch (e: Exception) { false }

    fun toggle() {
        if (reallyPlaying()) {
            resumeOnGain = false
            pause()
        } else {
            resume()
        }
    }

    fun pause() {
        try { if (mp?.isPlaying == true) mp?.pause() } catch (e: Exception) { }
        isPlaying = false
        changed()
    }

    fun resume() {
        val m = mp
        if (m == null) {
            // El reproductor se había liberado: se vuelve a crear con la canción actual
            if (current != null) startCurrent()
            return
        }
        resumeOnGain = false
        requestFocus()
        try {
            m.start()
            isPlaying = true
        } catch (e: Exception) {
            startCurrent()
            return
        }
        changed()
    }

    fun next() {
        if (queue.isEmpty()) return
        index = (index + 1) % queue.size
        startCurrent()
    }

    fun previous() {
        if (queue.isEmpty()) return
        if (position > 3000) {
            seekTo(0)
            return
        }
        index = (index - 1 + queue.size) % queue.size
        startCurrent()
    }

    fun seekTo(ms: Int) {
        try { mp?.seekTo(ms) } catch (e: Exception) { }
        changed()
    }

    fun stop() {
        release()
        abandonFocus()
        queue = emptyList()
        index = -1
        isPlaying = false
        resumeOnGain = false
        changed()
    }

    private fun release() {
        try { mp?.release() } catch (e: Exception) { }
        mp = null
    }

    private fun requestFocus() {
        val c = app ?: return
        c.getSystemService(AudioManager::class.java).requestAudioFocus(focusRequest)
    }

    private fun abandonFocus() {
        val c = app ?: return
        c.getSystemService(AudioManager::class.java).abandonAudioFocusRequest(focusRequest)
    }
}
