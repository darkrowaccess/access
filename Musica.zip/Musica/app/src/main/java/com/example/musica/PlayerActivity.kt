package com.example.musica

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class PlayerActivity : BaseActivity() {

    private lateinit var cover: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var bar: SeekBar
    private lateinit var cur: TextView
    private lateinit var total: TextView
    private lateinit var playBtn: TextView
    private lateinit var repeatBtn: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var tracking = false
    private val listener: () -> Unit = { updateAll() }
    private val ticker = object : Runnable {
        override fun run() {
            if (!tracking) updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER
        content.setPadding(ui.dp(28), ui.dp(16), ui.dp(28), ui.dp(16))

        cover = ImageView(this)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        val cbg = GradientDrawable()
        cbg.cornerRadius = ui.dp(16).toFloat()
        cbg.setColor(0xFF1C1C1C.toInt())
        cover.background = cbg
        cover.clipToOutline = true
        val clp = LinearLayout.LayoutParams(ui.dp(260), ui.dp(260))
        clp.bottomMargin = ui.dp(32)
        content.addView(cover, clp)

        title = ui.text("", 22f, Color.WHITE, true)
        title.gravity = Gravity.CENTER
        title.maxLines = 2
        content.addView(title)

        artist = ui.text("", 16f, GRAY, false)
        artist.gravity = Gravity.CENTER
        artist.setPadding(0, ui.dp(4), 0, ui.dp(24))
        content.addView(artist)

        bar = SeekBar(this)
        ui.whiteSeek(bar)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) cur.text = ui.time(p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                tracking = true
            }

            override fun onStopTrackingTouch(s: SeekBar?) {
                tracking = false
                Player.seekTo(bar.progress)
            }
        })
        content.addView(bar)

        val times = LinearLayout(this)
        times.orientation = LinearLayout.HORIZONTAL
        cur = ui.text("0:00", 13f, GRAY, false)
        total = ui.text("0:00", 13f, GRAY, false)
        total.gravity = Gravity.END
        times.addView(cur, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        times.addView(total, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(times)

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        controls.setPadding(0, ui.dp(24), 0, 0)
        val prev = ui.flat("|◀") { Player.previous() }
        prev.textSize = 26f
        playBtn = ui.flat("▶") { Player.toggle() }
        playBtn.textSize = 40f
        val next = ui.flat("▶|") { Player.next() }
        next.textSize = 26f
        controls.addView(prev, LinearLayout.LayoutParams(ui.dp(80), ui.dp(80)))
        controls.addView(playBtn, LinearLayout.LayoutParams(ui.dp(96), ui.dp(96)))
        controls.addView(next, LinearLayout.LayoutParams(ui.dp(80), ui.dp(80)))
        content.addView(controls)

        repeatBtn = ui.flat("Repetir: no") { Player.cycleRepeat() }
        repeatBtn.textSize = 16f
        content.addView(repeatBtn)

        show(content)
        if (Player.current == null) finish()
    }

    override fun onResume() {
        super.onResume()
        Player.listeners.add(listener)
        handler.post(ticker)
        updateAll()
    }

    override fun onPause() {
        super.onPause()
        Player.listeners.remove(listener)
        handler.removeCallbacks(ticker)
    }

    private fun updateAll() {
        val s = Player.current
        if (s == null) {
            finish()
            return
        }
        title.text = s.title
        artist.text = s.artistLabel
        playBtn.text = if (Player.isPlaying) "||" else "▶"
        when (Player.repeatMode) {
            Player.REPEAT_ALL -> {
                repeatBtn.text = "Repetir: toda la lista"
                repeatBtn.setTextColor(Color.WHITE)
            }
            Player.REPEAT_ONE -> {
                repeatBtn.text = "Repetir: esta canción"
                repeatBtn.setTextColor(Color.WHITE)
            }
            else -> {
                repeatBtn.text = "Repetir: no"
                repeatBtn.setTextColor(GRAY)
            }
        }

        val bmp = if (Player.sourcePlaylist >= 0) Covers.bitmap(this, Player.sourcePlaylist, 2) else null
        if (bmp != null) {
            cover.setImageBitmap(bmp)
            cover.visibility = View.VISIBLE
        } else {
            cover.setImageDrawable(null)
            cover.visibility = View.GONE
        }
        updateProgress()
    }

    private fun updateProgress() {
        val d = Player.duration
        bar.max = d
        bar.progress = Player.position
        total.text = ui.time(d)
        cur.text = ui.time(Player.position)
    }
}
