package com.example.musica

import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.graphics.Color

class SongPickerActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("playlist_id", -1L)
        val pl = PlaylistStore.get(this, id)
        if (pl == null) {
            finish()
            return
        }
        if (Library.songs.isEmpty()) Library.load(this)
        val songs = Library.songs

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), 0)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = ui.text("Elegir canciones", 20f, Color.WHITE, true)
        title.setPadding(ui.dp(8), 0, 0, 0)
        top.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        val labels = songs.map { it.title + "  ·  " + it.artistLabel }
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, labels)
        for (i in songs.indices) {
            if (songs[i].id in pl.songIds) lv.setItemChecked(i, true)
        }

        top.addView(ui.flat("Listo") {
            val checked = HashSet<Long>()
            for (i in songs.indices) if (lv.isItemChecked(i)) checked.add(songs[i].id)
            val newIds = pl.songIds.filter { it in checked }.toMutableList()
            for (s in songs) if (s.id in checked && s.id !in newIds) newIds.add(s.id)
            pl.songIds = newIds
            PlaylistStore.upsert(this, pl)
            finish()
        })
        content.addView(top)
        content.addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        show(content)
    }
}
