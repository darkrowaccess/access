package com.example.musica

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView

class SongPickerActivity : BaseActivity() {

    private var shown: List<Song> = emptyList()
    private val checked = HashSet<Long>()
    private lateinit var lv: ListView

    /** Muestra solo las canciones que coinciden con la búsqueda, conservando lo ya tildado. */
    private fun showSongs(query: String) {
        shown = Library.search(query)
        val labels = shown.map { it.title + "  ·  " + it.artistLabel }
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, labels)
        for (i in shown.indices) {
            lv.setItemChecked(i, shown[i].id in checked)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("playlist_id", -1L)
        val pl = PlaylistStore.get(this, id)
        if (pl == null) {
            finish()
            return
        }
        if (Library.songs.isEmpty()) Library.load(this)
        checked.addAll(pl.songIds)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), 0)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = ui.text("Elegir canciones", 20f, Color.WHITE, true)
        title.setPadding(ui.dp(8), 0, 0, 0)
        top.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        lv = ListView(this)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.setOnItemClickListener { _, _, position, _ ->
            val s = shown[position]
            if (lv.isItemChecked(position)) checked.add(s.id) else checked.remove(s.id)
        }

        top.addView(ui.flat("Listo") {
            val newIds = pl.songIds.filter { it in checked }.toMutableList()
            for (s in Library.songs) if (s.id in checked && s.id !in newIds) newIds.add(s.id)
            pl.songIds = newIds
            PlaylistStore.upsert(this, pl)
            finish()
        })
        content.addView(top)
        content.addView(ui.searchBar { q -> showSongs(q) })
        content.addView(lv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        showSongs("")
        show(content)
    }
}
