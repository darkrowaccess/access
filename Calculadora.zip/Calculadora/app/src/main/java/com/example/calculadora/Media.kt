package com.example.calculadora

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.AudioAttributes
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.media.SoundPool
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

object ImageUtil {
    /** Reduce la imagen elegida a maxSide píxeles, corrige su rotación y la guarda dentro de la app. */
    fun saveFromUri(ctx: Context, uri: Uri, dest: File, maxSide: Int): Boolean {
        return try {
            val resolver = ctx.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: throw IllegalStateException("sin imagen")

            val orientation = runCatching {
                resolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                }
            }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees != 0f) {
                val m = Matrix()
                m.postRotate(degrees)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(dest).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        } catch (e: Exception) {
            false
        }
    }
}

object AudioUtil {
    const val OK = 0
    const val INVALID = 1
    const val TOO_LONG = 2
    const val MAX_MS = 5000

    /** Copia el sonido elegido dentro de la app; solo acepta audios de hasta 5 segundos. */
    fun saveFromUri(ctx: Context, uri: Uri, dest: File): Int {
        val tmp = File(dest.path + ".tmp")
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: return INVALID
            input.use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o) } }

            var ms: Long? = null
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(tmp.path)
                ms = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            } finally {
                mmr.release()
            }
            if (ms == null || ms <= 0L) {
                tmp.delete()
                return INVALID
            }
            if (ms > MAX_MS) {
                tmp.delete()
                return TOO_LONG
            }
            dest.delete()
            if (!tmp.renameTo(dest)) {
                tmp.delete()
                return INVALID
            }
            return OK
        } catch (e: Exception) {
            tmp.delete()
            return INVALID
        }
    }
}

/** Reproduce el sonido de cada botón en el instante en que se toca. */
object Sounds {
    private var pool: SoundPool? = null
    private val ids = HashMap<String, Int>()

    fun init(ctx: Context) {
        if (pool == null) reload(ctx)
    }

    /** Vuelve a cargar los sonidos (al arrancar y cada vez que cambian en Personalizar). */
    fun reload(ctx: Context) {
        pool?.release()
        ids.clear()
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        pool = p
        val byPath = HashMap<String, Int>()
        for (k in Keys.all) {
            val f = Prefs.resolveSound(ctx, k.id) ?: continue
            val id = byPath.getOrPut(f.path + "|" + f.lastModified()) { p.load(f.path, 1) }
            ids[k.id] = id
        }
    }

    fun play(ctx: Context, key: String, force: Boolean = false) {
        if (!force && !Prefs.soundsOn(ctx)) return
        val id = ids[key] ?: return
        pool?.play(id, 1f, 1f, 1, 0, 1f)
    }
}
