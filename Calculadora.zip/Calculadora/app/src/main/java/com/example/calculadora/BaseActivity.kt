package com.example.calculadora

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout

open class BaseActivity : Activity() {
    protected lateinit var ui: Ui
    protected lateinit var backdrop: Backdrop

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        ui = Ui(this)
        backdrop = Backdrop(this)
    }

    protected fun show(content: View) {
        backdrop.addView(
            content,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        setContentView(backdrop)
    }

    override fun onResume() {
        super.onResume()
        backdrop.refresh()
    }
}
