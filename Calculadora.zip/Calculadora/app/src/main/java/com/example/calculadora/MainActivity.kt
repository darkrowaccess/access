package com.example.calculadora

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val calc = Calc()

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var bgImage: ImageView
    private lateinit var body: LinearLayout
    private lateinit var displayBox: FrameLayout
    private lateinit var display: TextView

    private val prefs by lazy { getSharedPreferences("calculadora", Context.MODE_PRIVATE) }
    private val bgFile by lazy { File(filesDir, "fondo.jpg") }

    private companion object {
        const val REQ_IMAGE = 1
        val DEFAULT_BG = 0xFFFFFFFF.toInt()
        val DEFAULT_BODY = 0xFFFBE88B.toInt()
        val DISPLAY_BG = 0xFFFBF7E6.toInt()
        val PALETTE = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFFF5F5F5.toInt(), 0xFF9E9E9E.toInt(), 0xFF212121.toInt(),
            0xFFFBE88B.toInt(), 0xFFFFD54F.toInt(), 0xFFFFB74D.toInt(), 0xFFFF8A65.toInt(),
            0xFFE57373.toInt(), 0xFFF48FB1.toInt(), 0xFFCE93D8.toInt(), 0xFFB39DDB.toInt(),
            0xFF9FA8DA.toInt(), 0xFF90CAF9.toInt(), 0xFF81D4FA.toInt(), 0xFF80DEEA.toInt(),
            0xFF80CBC4.toInt(), 0xFFA5D6A7.toInt(), 0xFFC5E1A5.toInt(), 0xFFE6EE9C.toInt()
        )
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        buildUi()
        applyAppearance()
        refreshDisplay()
    }

    // ------------------------------------------------------------------------------------ UI

    @Suppress("DEPRECATION")
    private fun buildUi() {
        root = FrameLayout(this)
        bgImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bgImage, FrameLayout.LayoutParams(-1, -1))

        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        // Pantalla completa detrás de las barras del sistema
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        root.setOnApplyWindowInsetsListener { _, insets ->
            content.setPadding(
                insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                insets.systemWindowInsetRight, insets.systemWindowInsetBottom
            )
            insets
        }

        // Cuerpo de la calculadora
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(16))
            elevation = dp(6).toFloat()
        }
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.setMargins(dp(16), dp(16), dp(16), dp(16))
        content.addView(body, lp)

        // Cabecera con el botón de ajustes (tres puntos)
        val header = FrameLayout(this)
        val dots = DotsView(this).apply {
            setOnClickListener { showMenu() }
            contentDescription = "Ajustes"
        }
        header.addView(dots, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.TOP))
        body.addView(header, LinearLayout.LayoutParams(-1, 0, 1.1f))

        // Pantalla
        display = TextView(this).apply {
            setTextColor(0xFF1B1B1B.toInt())
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            setPadding(dp(18), 0, dp(18), 0)
            setAutoSizeTextTypeUniformWithConfiguration(16, 44, 2, TypedValue.COMPLEX_UNIT_SP)
        }
        displayBox = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(DISPLAY_BG)
                cornerRadius = dp(14).toFloat()
            }
            // Un toque sobre la pantalla borra el último carácter
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                calc.backspace()
                refreshDisplay()
            }
        }
        displayBox.addView(display, FrameLayout.LayoutParams(-1, -1))
        body.addView(displayBox, LinearLayout.LayoutParams(-1, dp(84)).apply { bottomMargin = dp(14) })

        // Teclado: 5 filas grandes que se reparten todo el alto restante
        val keys = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(keys, LinearLayout.LayoutParams(-1, 0, 5.2f))

        keys.addView(row(key("C") { calc.clear() }, key("+/-") { calc.toggleSign() },
            key("%") { calc.percent() }, key("/") { calc.operator('÷') }))
        keys.addView(row(num('7'), num('8'), num('9'), key("×") { calc.operator('×') }))
        keys.addView(row(num('4'), num('5'), num('6'), key("−") { calc.operator('−') }))
        keys.addView(row(num('1'), num('2'), num('3'), key("+") { calc.operator('+') }))
        keys.addView(row(num('0'), key("·") { calc.dot() }, key("=", 2f) { calc.calculate() }))

        setContentView(root)
    }

    private fun row(vararg buttons: TextView): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (b in buttons) r.addView(b)
        r.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        return r
    }

    private fun num(d: Char) = key(d.toString()) { calc.digit(d) }

    private fun key(label: String, weight: Float = 1f, action: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = Gravity.CENTER
        tv.setTextColor(0xFF1B1B1B.toInt())
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label.length > 2) 22f else 30f)
        tv.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        tv.background = keyBackground()
        tv.elevation = dp(2).toFloat()
        tv.isClickable = true
        tv.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            action()
            refreshDisplay()
        }
        val lp = LinearLayout.LayoutParams(0, -1, weight)
        lp.setMargins(dp(5), dp(5), dp(5), dp(5))
        tv.layoutParams = lp
        return tv
    }

    private fun keyBackground(): StateListDrawable {
        fun shape(color: Int) = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), 0x1F000000)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(0xFFE9E4D0.toInt()))
            addState(intArrayOf(), shape(0xFFFFFFFF.toInt()))
        }
    }

    private fun refreshDisplay() {
        display.text = calc.display
    }

    /** Tres puntos verticales dibujados a mano, para no depender de iconos ni fuentes. */
    private class DotsView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A3A3A.toInt() }
        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val r = resources.displayMetrics.density * 2.6f
            val gap = resources.displayMetrics.density * 8f
            canvas.drawCircle(cx, cy - gap, r, paint)
            canvas.drawCircle(cx, cy, r, paint)
            canvas.drawCircle(cx, cy + gap, r, paint)
        }
    }

    // ------------------------------------------------------------------------- apariencia

    @Suppress("DEPRECATION")
    private fun applyAppearance() {
        val mode = prefs.getString("bg_mode", "default")
        val bgColor = prefs.getInt("bg_color", DEFAULT_BG)
        val bodyColor = prefs.getInt("body_color", DEFAULT_BODY)

        var showImage = false
        if (mode == "image" && bgFile.exists()) {
            val bmp: Bitmap? = try { BitmapFactory.decodeFile(bgFile.absolutePath) } catch (e: Exception) { null }
            if (bmp != null) {
                bgImage.setImageBitmap(bmp)
                showImage = true
            }
        }
        bgImage.visibility = if (showImage) View.VISIBLE else View.GONE
        if (!showImage) bgImage.setImageDrawable(null)

        val effectiveBg = if (mode == "color") bgColor else DEFAULT_BG
        root.setBackgroundColor(effectiveBg)
        body.background = GradientDrawable().apply {
            setColor(bodyColor)
            cornerRadius = dp(34).toFloat()
        }

        // Iconos de la barra de estado claros u oscuros según el fondo
        var flags = window.decorView.systemUiVisibility
        val lightBg = !showImage && isLight(effectiveBg)
        flags = if (lightBg) {
            flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        } else {
            flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        }
        window.decorView.systemUiVisibility = flags
        root.requestApplyInsets()
    }

    private fun isLight(c: Int): Boolean {
        val l = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
        return l > 150
    }

    // ----------------------------------------------------------------------------- ajustes

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_Material_Light_Dialog_Alert)

    private fun showMenu() {
        val items = arrayOf(
            "Fondo: color sólido",
            "Fondo: imagen de la galería",
            "Color de la calculadora",
            "Restaurar valores"
        )
        dialog().setTitle("Personalizar").setItems(items) { _, which ->
            when (which) {
                0 -> pickColor("Color de fondo", prefs.getInt("bg_color", DEFAULT_BG)) { c ->
                    prefs.edit().putString("bg_mode", "color").putInt("bg_color", c).apply()
                    applyAppearance()
                }
                1 -> pickImage()
                2 -> pickColor("Color de la calculadora", prefs.getInt("body_color", DEFAULT_BODY)) { c ->
                    prefs.edit().putInt("body_color", c).apply()
                    applyAppearance()
                }
                3 -> {
                    prefs.edit().clear().apply()
                    bgFile.delete()
                    applyAppearance()
                }
            }
        }.setNegativeButton("Cerrar", null).show()
    }

    private fun pickColor(title: String, current: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        var dlg: AlertDialog? = null

        val grid = GridLayout(this).apply { columnCount = 5 }
        for (c in PALETTE) {
            val sw = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(dp(if (c == current) 3 else 1), if (c == current) 0xFF000000.toInt() else 0x33000000)
                }
                setOnClickListener {
                    onPick(c)
                    dlg?.dismiss()
                }
            }
            val glp = GridLayout.LayoutParams().apply {
                width = dp(46); height = dp(46)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            grid.addView(sw, glp)
        }
        box.addView(grid)

        val hex = EditText(this).apply {
            hint = "Otro color, ej: #FF8800"
            setSingleLine()
        }
        box.addView(hex, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        dlg = dialog().setTitle(title).setView(box)
            .setPositiveButton("Aplicar") { _, _ ->
                val txt = hex.text.toString().trim()
                if (txt.isNotEmpty()) {
                    try {
                        onPick(Color.parseColor(if (txt.startsWith("#")) txt else "#$txt") or 0xFF000000.toInt())
                    } catch (e: Exception) {
                        Toast.makeText(this, "Color no válido", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .create()
        dlg?.show()
    }

    @Suppress("DEPRECATION")
    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        try {
            startActivityForResult(i, REQ_IMAGE)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir la galería", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMAGE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (ImageUtil.saveFromUri(this, uri, bgFile)) {
            prefs.edit().putString("bg_mode", "image").apply()
            applyAppearance()
        } else {
            Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_SHORT).show()
        }
    }
}
