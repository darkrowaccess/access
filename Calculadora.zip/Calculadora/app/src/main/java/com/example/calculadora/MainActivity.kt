package com.example.calculadora

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : BaseActivity() {

    private val calc = Calc()
    private lateinit var exprView: TextView
    private lateinit var curView: TextView
    private val buttons = ArrayList<CalcButton>()
    private var cache = HashMap<String, Bitmap?>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Sounds.init(this)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(10))

        // Barra de arriba: acceso a Personalizar
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.END
        top.addView(ui.flat("⚙  Personalizar") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        content.addView(top)

        // Pantalla de la calculadora
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.BOTTOM or Gravity.END
        val panelBg = GradientDrawable()
        panelBg.cornerRadius = ui.dp(24).toFloat()
        panelBg.setColor(Color.argb(110, 0, 0, 0))
        panel.background = panelBg
        panel.setPadding(ui.dp(18), ui.dp(12), ui.dp(18), ui.dp(12))

        exprView = ui.text("", 20f, GRAY, false)
        exprView.gravity = Gravity.END
        exprView.setSingleLine()
        exprView.ellipsize = TextUtils.TruncateAt.START
        panel.addView(
            exprView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        curView = ui.text("0", 56f, Color.WHITE, true)
        curView.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        curView.setSingleLine()
        curView.setAutoSizeTextTypeUniformWithConfiguration(28, 64, 2, TypedValue.COMPLEX_UNIT_SP)
        panel.addView(
            curView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ui.dp(84))
        )

        val panelLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        panelLp.bottomMargin = ui.dp(8)
        content.addView(panel, panelLp)

        // Teclado: 5 filas x 4 columnas de botones grandes
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val m = ui.dp(5)
        for (row in Keys.rows) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (k in row) {
                val b = CalcButton(this, k, ui)
                b.setOnClickListener {
                    calc.press(k.id)
                    render()
                }
                b.onDown = { Sounds.play(this, k.id) }
                buttons.add(b)
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                lp.setMargins(m, m, m, m)
                r.addView(b, lp)
            }
            grid.addView(r, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        content.addView(grid, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 3f))

        show(content)
        render()
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
    }

    private fun render() {
        exprView.text = calc.expr
        curView.text = calc.cur
    }

    /** Aplica las imágenes elegidas a los botones (las que se repiten se cargan una sola vez). */
    private fun refreshButtons() {
        val showLabel = Prefs.showLabels(this)
        val fresh = HashMap<String, Bitmap?>()
        for (b in buttons) {
            val f = Prefs.resolveImage(this, b.key.id)
            var bmp: Bitmap? = null
            if (f != null) {
                val ck = f.path + "|" + f.lastModified()
                bmp = if (fresh.containsKey(ck)) fresh[ck]
                else if (cache.containsKey(ck)) cache[ck]
                else BitmapFactory.decodeFile(f.path)
                fresh[ck] = bmp
            }
            b.style(bmp, showLabel)
        }
        cache = fresh
    }
}
