package com.example.calculadora

import android.content.Context
import java.io.File

/** Ajustes y archivos de personalización (todo se guarda dentro de la app). */
object Prefs {
    private const val P = "calc_prefs"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun bgFile(ctx: Context): File = File(ctx.filesDir, "bg.jpg")

    fun dim(ctx: Context): Int = sp(ctx).getInt("dim", 50)
    fun setDim(ctx: Context, v: Int) = sp(ctx).edit().putInt("dim", v).apply()

    fun soundsOn(ctx: Context): Boolean = sp(ctx).getBoolean("sounds", true)
    fun setSoundsOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("sounds", v).apply()

    fun showLabels(ctx: Context): Boolean = sp(ctx).getBoolean("labels", true)
    fun setShowLabels(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("labels", v).apply()

    /** key = id de un botón, o "all" para la imagen/sonido general de todos los botones. */
    fun imageFile(ctx: Context, key: String): File = File(ctx.filesDir, "btn_$key.jpg")
    fun soundFile(ctx: Context, key: String): File = File(ctx.filesDir, "snd_$key.bin")

    /** Imagen propia del botón; si no tiene, la general; si tampoco, ninguna. */
    fun resolveImage(ctx: Context, key: String): File? {
        val own = imageFile(ctx, key)
        if (own.exists()) return own
        val all = imageFile(ctx, "all")
        return if (all.exists()) all else null
    }

    fun resolveSound(ctx: Context, key: String): File? {
        val own = soundFile(ctx, key)
        if (own.exists()) return own
        val all = soundFile(ctx, "all")
        return if (all.exists()) all else null
    }

    fun clearImages(ctx: Context) {
        ctx.filesDir.listFiles()?.filter { it.name.startsWith("btn_") }?.forEach { it.delete() }
    }

    fun clearSounds(ctx: Context) {
        ctx.filesDir.listFiles()?.filter { it.name.startsWith("snd_") }?.forEach { it.delete() }
    }
}
