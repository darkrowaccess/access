package com.example.calculadora

import java.math.BigDecimal
import java.math.MathContext

/**
 * Motor de la calculadora. Sin dependencias de Android.
 *
 * Los operadores son + − × ÷ (el "−" es U+2212). El signo de un número negativo es el
 * guion normal "-", así nunca se confunde con la resta.
 */
class Calc {
    private val ops = charArrayOf('+', '−', '×', '÷')
    private val mc = MathContext(15)

    private var expr = ""
    private var lastExpr = ""
    private var justEvaluated = false
    private var error = false

    /** Texto que se muestra en la pantalla, por ejemplo "2+3=5". */
    val display: String
        get() = when {
            error -> "Error"
            justEvaluated -> "$lastExpr=$expr"
            expr.isEmpty() -> "0"
            else -> expr
        }

    private fun isOp(c: Char) = c in ops

    private fun currentNumber(): String {
        val i = expr.indexOfLast { isOp(it) }
        return expr.substring(i + 1)
    }

    /** Si venimos de un resultado o un error, un número nuevo empieza de cero. */
    private fun startFresh() {
        if (error || justEvaluated) {
            expr = ""
            lastExpr = ""
            error = false
            justEvaluated = false
        }
    }

    fun clear() {
        expr = ""
        lastExpr = ""
        error = false
        justEvaluated = false
    }

    fun backspace() {
        if (error || justEvaluated) {
            clear()
            return
        }
        expr = expr.dropLast(1)
    }

    fun digit(d: Char) {
        startFresh()
        val cur = currentNumber()
        val digits = cur.count { it.isDigit() }
        if (cur == "0" || cur == "-0") {
            if (d == '0') return
            expr = expr.dropLast(1) + d
            return
        }
        if (digits >= 15) return
        expr += d
    }

    fun dot() {
        startFresh()
        val cur = currentNumber()
        if (cur.contains('.')) return
        expr += if (cur.isEmpty() || cur == "-") "0." else "."
    }

    fun operator(o: Char) {
        if (error) return
        justEvaluated = false
        if (expr.isEmpty()) {
            expr = "0$o"
            return
        }
        if (expr == "-") return
        // "5×-" + operador -> quita el signo suelto
        if (expr.endsWith("-")) expr = expr.dropLast(1)
        if (expr.isNotEmpty() && isOp(expr.last())) {
            expr = expr.dropLast(1) + o
        } else {
            expr += o
        }
    }

    fun toggleSign() {
        if (error) return
        justEvaluated = false
        val i = expr.indexOfLast { isOp(it) }
        val cur = expr.substring(i + 1)
        expr = when {
            cur.isEmpty() -> expr + "-"
            cur.startsWith("-") -> expr.substring(0, i + 1) + cur.substring(1)
            else -> expr.substring(0, i + 1) + "-" + cur
        }
    }

    fun percent() {
        if (error) return
        justEvaluated = false
        val i = expr.indexOfLast { isOp(it) }
        val cur = expr.substring(i + 1)
        if (cur.isEmpty() || cur == "-") return
        val v = try {
            BigDecimal(cur).divide(BigDecimal(100), mc)
        } catch (e: Exception) {
            return
        }
        expr = expr.substring(0, i + 1) + format(v)
    }

    fun calculate() {
        if (error || justEvaluated) return
        var e = expr
        while (e.isNotEmpty() && (isOp(e.last()) || e.last() == '-')) e = e.dropLast(1)
        if (e.isEmpty() || e.none { isOp(it) }) return
        try {
            val r = evaluate(e)
            lastExpr = e
            expr = format(r)
            justEvaluated = true
        } catch (ex: Exception) {
            expr = ""
            lastExpr = ""
            error = true
            justEvaluated = false
        }
    }

    // ---------------------------------------------------------------------------------

    private fun evaluate(e: String): BigDecimal {
        val nums = ArrayList<BigDecimal>()
        val symbols = ArrayList<Char>()
        val sb = StringBuilder()
        for (c in e) {
            if (isOp(c)) {
                nums.add(BigDecimal(sb.toString()))
                sb.setLength(0)
                symbols.add(c)
            } else {
                sb.append(c)
            }
        }
        nums.add(BigDecimal(sb.toString()))

        // Primero × y ÷
        var i = 0
        while (i < symbols.size) {
            val s = symbols[i]
            if (s == '×' || s == '÷') {
                val a = nums[i]
                val b = nums[i + 1]
                nums[i] = if (s == '×') a.multiply(b, mc) else a.divide(b, mc) // ÷0 lanza excepción
                nums.removeAt(i + 1)
                symbols.removeAt(i)
            } else {
                i++
            }
        }
        // Después + y −
        var result = nums[0]
        for (k in symbols.indices) {
            result = if (symbols[k] == '+') result.add(nums[k + 1], mc) else result.subtract(nums[k + 1], mc)
        }
        return result
    }

    private fun format(v: BigDecimal): String {
        var r = v.round(MathContext(12))
        r = if (r.signum() == 0) BigDecimal.ZERO else r.stripTrailingZeros()
        val plain = r.toPlainString()
        return if (plain.length > 16) r.round(MathContext(8)).stripTrailingZeros().toString() else plain
    }
}
