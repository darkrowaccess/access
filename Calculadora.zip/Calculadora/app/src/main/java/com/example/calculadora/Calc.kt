package com.example.calculadora

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

enum class Kind { DIGIT, FUNC, OP, EQUALS }

data class Key(val id: String, val label: String, val kind: Kind)

object Keys {
    val rows: List<List<Key>> = listOf(
        listOf(Key("c", "C", Kind.FUNC), Key("back", "←", Kind.FUNC), Key("pct", "%", Kind.FUNC), Key("div", "÷", Kind.OP)),
        listOf(Key("7", "7", Kind.DIGIT), Key("8", "8", Kind.DIGIT), Key("9", "9", Kind.DIGIT), Key("mul", "×", Kind.OP)),
        listOf(Key("4", "4", Kind.DIGIT), Key("5", "5", Kind.DIGIT), Key("6", "6", Kind.DIGIT), Key("sub", "−", Kind.OP)),
        listOf(Key("1", "1", Kind.DIGIT), Key("2", "2", Kind.DIGIT), Key("3", "3", Kind.DIGIT), Key("add", "+", Kind.OP)),
        listOf(Key("neg", "±", Kind.FUNC), Key("0", "0", Kind.DIGIT), Key("dot", ".", Kind.DIGIT), Key("eq", "=", Kind.EQUALS))
    )
    val all: List<Key> = rows.flatten()
}

/** Motor de la calculadora (sin nada de Android): cuentas encadenadas, % y repetir "=". */
class Calc {
    private val mc = MathContext(40)
    private val hundred = BigDecimal(100)

    /** Número que se ve en pantalla. */
    var cur = "0"
        private set

    /** Línea chica de arriba, por ejemplo "5 + 3 =". */
    var expr = ""
        private set

    private var acc: BigDecimal? = null
    private var op: String? = null
    private var replace = true      // el próximo dígito empieza un número nuevo
    private var entered = false     // ya se escribió el segundo número de la operación pendiente
    private var lastOp: String? = null
    private var lastOperand: BigDecimal? = null
    private var error = false

    fun press(id: String) {
        if (error && id != "c") {
            if ((id.length == 1 && id[0].isDigit()) || id == "dot") clearAll() else return
        }
        when (id) {
            "c" -> clearAll()
            "back" -> backspace()
            "pct" -> percent()
            "neg" -> negate()
            "dot" -> dot()
            "eq" -> evaluate()
            "add", "sub", "mul", "div" -> chooseOp(id)
            else -> if (id.length == 1 && id[0].isDigit()) digit(id)
        }
    }

    private fun sym(o: String): String = when (o) {
        "add" -> "+"
        "sub" -> "−"
        "mul" -> "×"
        else -> "÷"
    }

    private fun value(): BigDecimal = cur.toBigDecimalOrNull() ?: BigDecimal.ZERO

    private fun fmt(v: BigDecimal): String {
        if (v.signum() == 0) return "0"
        val r = v.round(MathContext(15, RoundingMode.HALF_UP)).stripTrailingZeros()
        val exp = r.precision() - r.scale() - 1
        return if (exp >= 15 || exp <= -10) r.toString() else r.toPlainString()
    }

    private fun clearAll() {
        cur = "0"
        expr = ""
        acc = null
        op = null
        replace = true
        entered = false
        lastOp = null
        lastOperand = null
        error = false
    }

    private fun fail() {
        clearAll()
        cur = "Error"
        error = true
    }

    private fun beginNumber() {
        if (op == null) {
            expr = ""
            acc = null
            lastOp = null
            lastOperand = null
        }
    }

    private fun digit(d: String) {
        if (replace) {
            beginNumber()
            cur = d
            replace = false
        } else if (cur == "0") {
            cur = d
        } else if (cur.count { it.isDigit() } < 15) {
            cur += d
        }
        entered = true
    }

    private fun dot() {
        if (replace) {
            beginNumber()
            cur = "0."
            replace = false
        } else if (!cur.contains('.')) {
            cur += "."
        }
        entered = true
    }

    private fun backspace() {
        if (replace) return
        var t = cur.dropLast(1)
        if (t.isEmpty() || t == "-" || t == "-0") t = "0"
        cur = t
    }

    private fun negate() {
        if (value().signum() == 0 && !cur.contains('.')) return
        cur = if (cur.startsWith("-")) cur.substring(1) else "-$cur"
        if (op != null && !entered) entered = true
    }

    private fun percent() {
        val v = value()
        val a = acc
        val p = op
        val r = if (a != null && p != null && (p == "add" || p == "sub")) {
            a.multiply(v, mc).divide(hundred, mc)
        } else {
            v.divide(hundred, mc)
        }
        cur = fmt(r)
        replace = true
        entered = true
    }

    private fun apply(a: BigDecimal, o: String, b: BigDecimal): BigDecimal? {
        return when (o) {
            "add" -> a.add(b, mc)
            "sub" -> a.subtract(b, mc)
            "mul" -> a.multiply(b, mc)
            else -> {
                if (b.signum() == 0) {
                    fail()
                    null
                } else {
                    a.divide(b, mc)
                }
            }
        }
    }

    private fun chooseOp(o: String) {
        val pending = op
        if (pending != null && entered) {
            val r = apply(acc!!, pending, value()) ?: return
            acc = r
            cur = fmt(r)
        } else if (pending == null) {
            acc = value()
        }
        op = o
        replace = true
        entered = false
        expr = fmt(acc!!) + " " + sym(o)
    }

    private fun evaluate() {
        val pending = op
        if (pending != null) {
            val a = acc!!
            val b = if (entered) value() else a
            val r = apply(a, pending, b) ?: return
            expr = fmt(a) + " " + sym(pending) + " " + fmt(b) + " ="
            lastOp = pending
            lastOperand = b
            acc = null
            op = null
            cur = fmt(r)
            replace = true
            entered = false
        } else {
            val lo = lastOp
            val lb = lastOperand
            if (lo != null && lb != null) {
                val a = value()
                val r = apply(a, lo, lb) ?: return
                expr = fmt(a) + " " + sym(lo) + " " + fmt(lb) + " ="
                cur = fmt(r)
                replace = true
            }
        }
    }
}
