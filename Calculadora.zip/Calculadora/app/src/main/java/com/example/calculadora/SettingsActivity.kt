package com.example.calculadora

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : BaseActivity() {

    private val reqBg = 31
    private val reqImg = 32
    private val reqSnd = 33
    private var pendingKey = "all"

    private lateinit var list: LinearLayout
    private lateinit var soundsToggle: TextView
    private lateinit var labelsToggle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingKey = savedInstanceState?.getString("key") ?: "all"

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(24))

        col.addView(ui.flat("‹  Volver") { finish() })
        val title = ui.text("Personalizar", 26f, Color.WHITE, true)
        title.setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(4))
        col.addView(title)

        // Fondo
        col.addView(ui.header("FONDO"))
        col.addView(ui.flat("Elegir imagen de fondo") {
            startActivityForResult(pick("image/*", "Elegir imagen"), reqBg)
        })
        col.addView(ui.flat("Quitar imagen de fondo") {
            Prefs.bgFile(this).delete()
            backdrop.refresh()
        })
        col.addView(ui.seekRow("Oscurecer el fondo", Prefs.dim(this), 95) {
            Prefs.setDim(this, it)
            backdrop.refresh()
        })

        // Opciones generales
        col.addView(ui.header("OPCIONES"))
        soundsToggle = ui.flat("") {
            Prefs.setSoundsOn(this, !Prefs.soundsOn(this))
            refreshToggles()
        }
        labelsToggle = ui.flat("") {
            Prefs.setShowLabels(this, !Prefs.showLabels(this))
            refreshToggles()
        }
        col.addView(soundsToggle)
        col.addView(labelsToggle)
        refreshToggles()

        // Todos los botones a la vez
        col.addView(ui.header("TODOS LOS BOTONES"))
        col.addView(ui.flat("Elegir una imagen para todos los botones") { pickImage("all") })
        col.addView(ui.flat("Elegir un sonido para todos los botones") { pickSound("all") })
        col.addView(ui.flat("Quitar todas las imágenes de los botones") {
            ui.confirm("¿Quitar todas las imágenes de los botones?", "Quitar") {
                Prefs.clearImages(this)
                refreshList()
            }
        })
        col.addView(ui.flat("Quitar todos los sonidos") {
            ui.confirm("¿Quitar todos los sonidos?", "Quitar") {
                Prefs.clearSounds(this)
                Sounds.reload(this)
                refreshList()
            }
        })

        // Cada botón por separado
        col.addView(ui.header("CADA BOTÓN POR SEPARADO (toca uno para cambiarlo)"))
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        refreshList()

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(col)
        show(scroll)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("key", pendingKey)
    }

    private fun pick(type: String, title: String): Intent {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = type
        i.addCategory(Intent.CATEGORY_OPENABLE)
        return Intent.createChooser(i, title)
    }

    private fun pickImage(key: String) {
        pendingKey = key
        startActivityForResult(pick("image/*", "Elegir imagen"), reqImg)
    }

    private fun pickSound(key: String) {
        pendingKey = key
        startActivityForResult(pick("audio/*", "Elegir sonido"), reqSnd)
    }

    private fun refreshToggles() {
        soundsToggle.text = "Sonido al presionar: " + if (Prefs.soundsOn(this)) "activado" else "desactivado"
        labelsToggle.text = "Texto sobre las imágenes: " + if (Prefs.showLabels(this)) "visible" else "oculto"
    }

    private fun status(own: Boolean, general: Boolean): String =
        if (own) "propia" else if (general) "general" else "ninguna"

    private fun refreshList() {
        list.removeAllViews()
        val allImg = Prefs.imageFile(this, "all").exists()
        val allSnd = Prefs.soundFile(this, "all").exists()
        for (k in Keys.all) {
            val img = status(Prefs.imageFile(this, k.id).exists(), allImg)
            val snd = status(Prefs.soundFile(this, k.id).exists(), allSnd)
            val row = ui.row("Botón " + k.label, "Imagen: $img   ·   Sonido: $snd")
            row.setOnClickListener { options(k) }
            list.addView(row)
        }
    }

    private fun options(k: Key) {
        val items = arrayOf("Elegir imagen", "Quitar imagen", "Elegir sonido", "Quitar sonido", "Probar sonido")
        AlertDialog.Builder(this)
            .setTitle("Botón " + k.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pickImage(k.id)
                    1 -> {
                        Prefs.imageFile(this, k.id).delete()
                        refreshList()
                    }
                    2 -> pickSound(k.id)
                    3 -> {
                        Prefs.soundFile(this, k.id).delete()
                        Sounds.reload(this)
                        refreshList()
                    }
                    4 -> Sounds.play(this, k.id, true)
                }
            }
            .show()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val key = pendingKey
        when (requestCode) {
            reqBg -> Thread {
                val ok = ImageUtil.saveFromUri(this, uri, Prefs.bgFile(this), 1600)
                runOnUiThread {
                    if (ok) backdrop.refresh() else toast("No se pudo usar esa imagen")
                }
            }.start()
            reqImg -> Thread {
                val ok = ImageUtil.saveFromUri(this, uri, Prefs.imageFile(this, key), 480)
                runOnUiThread {
                    if (ok) refreshList() else toast("No se pudo usar esa imagen")
                }
            }.start()
            reqSnd -> Thread {
                val r = AudioUtil.saveFromUri(this, uri, Prefs.soundFile(this, key))
                runOnUiThread {
                    when (r) {
                        AudioUtil.OK -> {
                            Sounds.reload(this)
                            refreshList()
                            toast("Sonido guardado")
                        }
                        AudioUtil.TOO_LONG -> toast("Ese sonido dura más de 5 segundos. Elegí uno más corto.")
                        else -> toast("No se pudo usar ese audio")
                    }
                }
            }.start()
        }
    }
}
