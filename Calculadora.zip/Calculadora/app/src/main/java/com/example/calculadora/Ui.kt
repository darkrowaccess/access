package com.example.calculadora

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

const val GRAY = 0xFF9E9E9E.toInt()

class Ui(private val ctx: Context) {

    fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun text(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        return v
    }

    /** Botón de texto plano, sin caja, estilo minimalista. */
    fun flat(label: String, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = label
        t.textSize = 16f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        t.setPadding(dp(12), dp(14), dp(12), dp(14))
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        t.setBackgroundResource(tv.resourceId)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    /** Fila con título y subtítulo. */
    fun row(title: String, subtitle: String): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(10), dp(12), dp(10))
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        box.setBackgroundResource(tv.resourceId)
        box.addView(text(title, 16f, Color.WHITE, false))
        box.addView(text(subtitle, 13f, GRAY, false))
        return box
    }

    fun header(t: String): TextView {
        val v = text(t, 13f, GRAY, true)
        v.setPadding(dp(12), dp(24), dp(12), dp(4))
        return v
    }

    fun confirm(title: String, ok: String, onOk: () -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setPositiveButton(ok) { _, _ -> onOk() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    fun seekRow(title: String, current: Int, maxValue: Int, onDone: (Int) -> Unit): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val label = text("$title: $current%", 16f, Color.WHITE, false)
        label.setPadding(dp(12), dp(16), dp(12), 0)
        val bar = SeekBar(ctx)
        bar.progressTintList = ColorStateList.valueOf(Color.WHITE)
        bar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        bar.max = maxValue
        bar.progress = current
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "$title: $p%"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                onDone(bar.progress)
            }
        })
        box.addView(label)
        box.addView(bar)
        return box
    }
}

/** Fondo de todas las pantallas: negro, o la imagen elegida (oscurecida a gusto). */
class Backdrop(ctx: Context) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    private val dim = View(ctx)

    init {
        setBackgroundColor(Color.BLACK)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(img, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(dim, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    fun refresh() {
        val f = Prefs.bgFile(context)
        if (f.exists()) {
            img.setImageBitmap(BitmapFactory.decodeFile(f.path))
            dim.setBackgroundColor(Color.argb(Prefs.dim(context) * 255 / 100, 0, 0, 0))
        } else {
            img.setImageDrawable(null)
            dim.setBackgroundColor(Color.TRANSPARENT)
        }
    }
}

/** Botón grande de la calculadora: color liso o imagen elegida, con el texto encima. */
class CalcButton(ctx: Context, val key: Key, ui: Ui) : FrameLayout(ctx) {
    var onDown: (() -> Unit)? = null
    private val img = ImageView(ctx)
    private val label = TextView(ctx)
    private var textColor = Color.WHITE

    init {
        val fill = when (key.kind) {
            Kind.DIGIT -> {
                textColor = Color.WHITE
                0xFF333336.toInt()
            }
            Kind.FUNC -> {
                textColor = Color.BLACK
                0xFFA5A5A8.toInt()
            }
            Kind.OP, Kind.EQUALS -> {
                textColor = Color.WHITE
                0xFFFF9F0A.toInt()
            }
        }
        val bg = GradientDrawable()
        bg.cornerRadius = ui.dp(24).toFloat()
        bg.setColor(fill)
        background = bg
        clipToOutline = true
        isClickable = true
        contentDescription = key.label

        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.visibility = View.GONE
        addView(img, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        label.text = key.label
        label.textSize = if (key.kind == Kind.DIGIT) 32f else 30f
        label.gravity = Gravity.CENTER
        label.setTextColor(textColor)
        addView(label, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(60).start()
                    onDown?.invoke()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                }
            }
            false
        }
    }

    /** Pone o quita la imagen del botón. */
    fun style(bmp: Bitmap?, showLabel: Boolean) {
        if (bmp != null) {
            img.setImageBitmap(bmp)
            img.visibility = View.VISIBLE
            label.visibility = if (showLabel) View.VISIBLE else View.GONE
            label.setTextColor(Color.WHITE)
            label.setShadowLayer(10f, 0f, 0f, Color.BLACK)
        } else {
            img.setImageDrawable(null)
            img.visibility = View.GONE
            label.visibility = View.VISIBLE
            label.setTextColor(textColor)
            label.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        }
    }
}
